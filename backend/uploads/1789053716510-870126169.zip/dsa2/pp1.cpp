#include<iostream>
#include<bits/stdc++.h>
using namespace std;
bool adj(string a,string b){
    int d=0;
    for(int i=0;i<a.length();i++){
        if(a[i]!=b[i])
        d++;
        if(d>1)
        return false;
    }
    return d==1;
}
int main(){
    cout<<"enter number of words: "<<endl;
    int n;
    cin>>n;
    cout<<"Enter start and target: "<<endl;
    string s,t;
    cin>>s;
    cout<<"enter target"<<endl;
    cin>>t;
    vector<string> words(n);
    for(int i=0;i<n;i++){
        cin>>words[i];
    }
    
    if(s==t){
        cout<<"cost is 0 "<<endl;
        return 0;
    }
    vector<bool> visited(n,false);
    queue<pair<int,int>> q;
    int sid=-1;
    for(int i=0;i<n;i++){
        if(words[i]==s)
       { 
        sid=i;
        break;
    }
    }
    q.push({sid,0});
    visited[sid]=true;
    while(!q.empty()){
        pair<int,int> cur=q.front();
        q.pop();
       
        string cw=words[cur.first];
        for(int i=0;i<n;i++){
            if(!visited[i]&&adj(cw,words[i]))
            {
                if(words[i]==t)
                {
                    cout<<"distance is "<<cur.second+1;
                    return 0;
                }
                visited[i]=true;
                q.push({i,cur.second+1});
            }
        }
    }
    cout<<-1;
}