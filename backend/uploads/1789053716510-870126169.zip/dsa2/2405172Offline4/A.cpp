#include <bits/stdc++.h>

using namespace std;

const long long SENTINEL_MIN = INT_MIN;

class Node {
public:
    long long key;
    int degree;
    Node* parent;
    Node* child;
    Node* sibling;

    Node(long long k) {
        key = k;
        degree = 0;
        parent = nullptr;
        child = nullptr;
        sibling = nullptr;
    }
};

class DualOutput {
private:
    ofstream fout;
public:
    DualOutput( string filename) {
        fout.open(filename);
    }
    ~DualOutput() {
        if (fout.is_open()) fout.close();
    }
    void print( string s) {
        cout << s;
        if (fout.is_open()) fout << s;
    }
    void println( string s = "") {
        cout << s << "\n";
        if (fout.is_open()) fout << s << "\n";
    }
};

DualOutput* outWriter = nullptr;

class BinomialHeap {
public:
    Node* head;
    int size;

    BinomialHeap() {
        head = nullptr;
        size = 0;
    }

    static void linkTrees(Node* y, Node* z) {
        y->parent = z;
        y->sibling = z->child;
        z->child = y;
        z->degree++;
    }

    static Node* mergeRootLists(Node* h1, Node* h2) {
        if (!h1) return h2;
        if (!h2) return h1;

        Node* newHead = nullptr;
        Node* tail = nullptr;

        if (h1->degree <= h2->degree) {
            newHead = h1;
            h1 = h1->sibling;
        } else {
            newHead = h2;
            h2 = h2->sibling;
        }
        tail = newHead;

        while (h1 && h2) {
            if (h1->degree <= h2->degree) {
                tail->sibling = h1;
                h1 = h1->sibling;
            } else {
                tail->sibling = h2;
                h2 = h2->sibling;
            }
            tail = tail->sibling;
        }

        if (h1) tail->sibling = h1;
        else tail->sibling = h2;

        return newHead;
    }

    static Node* unionHeaps(Node* h1, Node* h2) {
        Node* newHead = mergeRootLists(h1, h2);
        if (!newHead) return nullptr;

        Node* prev = nullptr;
        Node* curr = newHead;
        Node* next = curr->sibling;

        while (next) {
            if ((curr->degree != next->degree) || 
                (next->sibling && next->sibling->degree == curr->degree)) {
                prev = curr;
                curr = next;
            } 
            else if (curr->key <= next->key) {
                curr->sibling = next->sibling;
                linkTrees(next, curr);
            } 
            else {
                if (!prev) {
                    newHead = next;
                } else {
                    prev->sibling = next;
                }
                linkTrees(curr, next);
                curr = next;
            }
            next = curr->sibling;
        }
        return newHead;
    }

    void insert(long long x) {
        Node* node = new Node(x);

        BinomialHeap tempHeap;
        tempHeap.head = node;
        tempHeap.size = 1;

        this->head = unionHeaps(this->head, tempHeap.head);
        this->size += 1;
    }

    long long findMin() const {
        Node* curr = head;
        long long minKey = LLONG_MAX;
        while (curr) {
            if (curr->key < minKey) {
                minKey = curr->key;
            }
            curr = curr->sibling;
        }
        return minKey;
    }

    long long extractMin() {
        if (!head) return LLONG_MAX;

        Node* prev = nullptr;
        Node* curr = head;
        Node* minPrev = nullptr;
        Node* minNode = head;
        long long minKey = head->key;

        while (curr) {
            if (curr->key < minKey) {
                minKey = curr->key;
                minNode = curr;
                minPrev = prev;
            }
            prev = curr;
            curr = curr->sibling;
        }

        if (!minPrev) {
            head = minNode->sibling;
        } else {
            minPrev->sibling = minNode->sibling;
        }

        Node* childHead = nullptr;
        Node* child = minNode->child;
        while (child) {
            Node* nextChild = child->sibling;
            child->sibling = childHead;
            child->parent = nullptr;
            childHead = child;
            child = nextChild;
        }

        head = unionHeaps(head, childHead);
        size--;

        delete minNode;
        return minKey;
    }

    static Node* findNode(Node* root, long long k) {
        if (!root) return nullptr;
        if (root->key == k) return root;

        Node* res = findNode(root->child, k);
        if (res) return res;

        return findNode(root->sibling, k);
    }

    Node* search(long long k) {
        Node* curr = head;
        while (curr) {
            Node* res = findNode(curr, k);
            if (res) return res;
            curr = curr->sibling;
        }
        return nullptr;
    }

    void decreaseKey(long long x, long long y) {
        Node* node = search(x);
        if (!node) return;

        node->key = y;
        Node* curr = node;
        Node* p = curr->parent;

        while (p && curr->key < p->key) {
            swap(curr->key, p->key);
            curr = p;
            p = curr->parent;
        }
    }

    void removeKey(long long x) {
        decreaseKey(x, SENTINEL_MIN);
        extractMin();
    }

    void print( string heapName)  {
        outWriter->println("Printing Binomial Heap " + heapName);
        outWriter->println("Heap size: " + to_string(size));

        if (size == 0) {
            outWriter->println("Heap " + heapName + " is empty.");
            return;
        }

        Node* currTree = head;
        while (currTree) {
            outWriter->println("Binomial Tree, B" + to_string(currTree->degree));

            queue<pair<Node*, int>> q;
            q.push({currTree, 0});

            int currentLevel = 0;
            vector<long long> levelKeys;

            while (!q.empty()) {
                auto [node, level] = q.front();
                q.pop();

                if (level != currentLevel) {
                    sort(levelKeys.begin(), levelKeys.end());
                    string line = "Level " + to_string(currentLevel) + ":";
                    for (long long k : levelKeys) {
                        line += " " + to_string(k);
                    }
                    outWriter->println(line);

                    levelKeys.clear();
                    currentLevel = level;
                }

                levelKeys.push_back(node->key);

                Node* child = node->child;
                while (child) {
                    q.push({child, level + 1});
                    child = child->sibling;
                }
            }

            if (!levelKeys.empty()) {
                sort(levelKeys.begin(), levelKeys.end());
                string line = "Level " + to_string(currentLevel) + ":";
                for (long long k : levelKeys) {
                    line += " " + to_string(k);
                }
                outWriter->println(line);
            }

            currTree = currTree->sibling;
        }
    }
};

int main() {
    ifstream fin("input.txt");
    if (!fin.is_open()) return 0;

    outWriter = new DualOutput("output.txt");

    BinomialHeap H1;
    BinomialHeap H2;

    string op;
    while (fin >> op) {
        if (op == "I") {
            int h;
            long long x;
            fin >> h >> x;
            if (h == 1) H1.insert(x);
            else H2.insert(x);
        } else if (op == "F") {
            int h;
            fin >> h;
            long long m = (h == 1) ? H1.findMin() : H2.findMin();
            outWriter->println("Find Min returned: " + to_string(m));
        } else if (op == "E") {
            int h;
            fin >> h;
            long long m = (h == 1) ? H1.extractMin() : H2.extractMin();
            outWriter->println("Extract Min returned: " + to_string(m));
        } else if (op == "D") {
            int h;
            long long x, y;
            fin >> h >> x >> y;
            if (h == 1) H1.decreaseKey(x, y);
            else H2.decreaseKey(x, y);
        } else if (op == "R") {
            int h;
            long long x;
            fin >> h >> x;
            if (h == 1) H1.removeKey(x);
            else H2.removeKey(x);
        } else if (op == "U") {
            int h1, h2;
            fin >> h1 >> h2;
            if (h1 == 1 && h2 == 2) {
                H1.head = BinomialHeap::unionHeaps(H1.head, H2.head);
                H1.size += H2.size;
                H2.head = nullptr;
                H2.size = 0;
            } else if (h1 == 2 && h2 == 1) {
                H2.head = BinomialHeap::unionHeaps(H2.head, H1.head);
                H2.size += H1.size;
                H1.head = nullptr;
                H1.size = 0;
            }
        } else if (op == "P") {
            int h;
            fin >> h;
            if (h == 1) H1.print("H1");
            else H2.print("H2");
        }
    }

    delete outWriter;
    return 0;
}