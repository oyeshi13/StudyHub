#include <iostream>
#include <bits/stdc++.h>

using namespace std;

class IntervalNode {
public:
    int id;
    int start;
    int end;
    int maxEnd;
    int height;
    IntervalNode* left;
    IntervalNode* right;

    IntervalNode(int i, int s, int e) {
        id = i;
        start = s;
        end = e;
        maxEnd = e;
        height = 1;
        left = nullptr;
        right = nullptr;
    }
};

class IntervalAVLTree {
    IntervalNode* root;
    int nextId;

    int getHeight(IntervalNode* node) {
        if (node == nullptr) return 0;
        return node->height;
    }

    int getMaxEnd(IntervalNode* node) {
        if (node == nullptr) return -2147483648;
        return node->maxEnd;
    }

    int getBalanceFactor(IntervalNode* node) {
        if (node == nullptr) return 0;
        return getHeight(node->left) - getHeight(node->right);
    }

    void updateNode(IntervalNode* node) {
        if (node != nullptr) {
            node->height = 1 + max(getHeight(node->left), getHeight(node->right));
            int m = node->end;
            if (node->left != nullptr) m = max(m, node->left->maxEnd);
            if (node->right != nullptr) m = max(m, node->right->maxEnd);
            node->maxEnd = m;
        }
    }

    IntervalNode* rotateRight(IntervalNode* y) {
        IntervalNode* x = y->left;
        IntervalNode* T2 = x->right;

        x->right = y;
        y->left = T2;

        updateNode(y);
        updateNode(x);

        return x;
    }

    IntervalNode* rotateLeft(IntervalNode* x) {
        IntervalNode* y = x->right;
        IntervalNode* T2 = y->left;

        y->left = x;
        x->right = T2;

        updateNode(x);
        updateNode(y);

        return y;
    }

    bool compareLess(int s1, int id1, int s2, int id2) {
        if (s1 != s2) return s1 < s2;
        return id1 < id2;
    }

    IntervalNode* findNodeById(IntervalNode* node, int id) {
        if (node == nullptr) return nullptr;
        if (node->id == id) return node;
        IntervalNode* leftRes = findNodeById(node->left, id);
        if (leftRes != nullptr) return leftRes;
        return findNodeById(node->right, id);
    }

    IntervalNode* insertHelper(IntervalNode* node, int id, int s, int e) {
        if (node == nullptr) {
            return new IntervalNode(id, s, e);
        }

        if (compareLess(s, id, node->start, node->id)) {
            node->left = insertHelper(node->left, id, s, e);
        } else {
            node->right = insertHelper(node->right, id, s, e);
        }

        updateNode(node);
        int bf = getBalanceFactor(node);

        if (bf > 1) {
            if (getBalanceFactor(node->left) >= 0) {
                return rotateRight(node);
            } else {
                node->left = rotateLeft(node->left);
                return rotateRight(node);
            }
        }
        if (bf < -1) {
            if (getBalanceFactor(node->right) <= 0) {
                return rotateLeft(node);
            } else {
                node->right = rotateRight(node->right);
                return rotateLeft(node);
            }
        }

        return node;
    }

    IntervalNode* findMin(IntervalNode* node) {
        while (node != nullptr && node->left != nullptr) {
            node = node->left;
        }
        return node;
    }

    IntervalNode* eraseHelper(IntervalNode* node, int id, int s, int e) {
        if (node == nullptr) return nullptr;

        if (compareLess(s, id, node->start, node->id)) {
            node->left = eraseHelper(node->left, id, s, e);
        } else if (compareLess(node->start, node->id, s, id)) {
            node->right = eraseHelper(node->right, id, s, e);
        } else {
            if (node->left == nullptr || node->right == nullptr) {
                IntervalNode* temp = (node->left != nullptr) ? node->left : node->right;
                if (temp == nullptr) {
                    temp = node;
                    node = nullptr;
                } else {
                    node->id = temp->id;
                    node->start = temp->start;
                    node->end = temp->end;
                    node->maxEnd = temp->maxEnd;
                    node->height = temp->height;
                    node->left = temp->left;
                    node->right = temp->right;
                }
                delete temp;
            } else {
                IntervalNode* successor = findMin(node->right);
                node->id = successor->id;
                node->start = successor->start;
                node->end = successor->end;
                node->right = eraseHelper(node->right, successor->id, successor->start, successor->end);
            }
        }

        if (node == nullptr) return nullptr;

        updateNode(node);
        int bf = getBalanceFactor(node);

        if (bf > 1) {
            if (getBalanceFactor(node->left) >= 0) {
                return rotateRight(node);
            } else {
                node->left = rotateLeft(node->left);
                return rotateRight(node);
            }
        }
        if (bf < -1) {
            if (getBalanceFactor(node->right) <= 0) {
                return rotateLeft(node);
            } else {
                node->right = rotateRight(node->right);
                return rotateLeft(node);
            }
        }

        return node;
    }

    bool hasConflictHelper(IntervalNode* node, int s, int e) {
        if (node == nullptr) return false;
        if (node->start < e && s < node->end) return true;

        if (node->left != nullptr && node->left->maxEnd > s) {
            if (hasConflictHelper(node->left, s, e)) return true;
        }

        if (node->start < e) {
            return hasConflictHelper(node->right, s, e);
        }

        return false;
    }

    void overlapsHelper(IntervalNode* node, int s, int e, vector<int>& res) {
        if (node == nullptr) return;

        if (node->left != nullptr && node->left->maxEnd > s) {
            overlapsHelper(node->left, s, e, res);
        }

        if (node->start < e && s < node->end) {
            res.push_back(node->id);
        }

        if (node->start < e) {
            overlapsHelper(node->right, s, e, res);
        }
    }

    void atHelper(IntervalNode* node, int t, vector<int>& res) {
        if (node == nullptr) return;

        if (node->left != nullptr && node->left->maxEnd > t) {
            atHelper(node->left, t, res);
        }

        if (node->start <= t && t < node->end) {
            res.push_back(node->id);
        }

        if (node->start <= t) {
            atHelper(node->right, t, res);
        }
    }

    void nextHelper(IntervalNode* node, int t, IntervalNode*& best) {
        if (node == nullptr) return;
        if (node->start >= t) {
            best = node;
            nextHelper(node->left, t, best);
        } else {
            nextHelper(node->right, t, best);
        }
    }

    void serializeHelper(IntervalNode* node, string& out) {
        if (node == nullptr) return;
        out += to_string(node->id);
        if (node->left != nullptr || node->right != nullptr) {
            out += "(";
            serializeHelper(node->left, out);
            out += ",";
            serializeHelper(node->right, out);
            out += ")";
        }
    }

    void destroyHelper(IntervalNode* node) {
        if (node == nullptr) return;
        destroyHelper(node->left);
        destroyHelper(node->right);
        delete node;
    }

public:
    IntervalAVLTree() {
        root = nullptr;
        nextId = 1;
    }

    ~IntervalAVLTree() {
        destroyHelper(root);
    }

    int add(int s, int e) {
        int assignedId = nextId++;
        root = insertHelper(root, assignedId, s, e);
        return assignedId;
    }

    bool remove(int id) {
        IntervalNode* target = findNodeById(root, id);
        if (target == nullptr) return false;
        int s = target->start;
        int e = target->end;
        root = eraseHelper(root, id, s, e);
        return true;
    }

    bool update(int id, int s, int e) {
        IntervalNode* target = findNodeById(root, id);
        if (target == nullptr) return false;
        int oldS = target->start;
        int oldE = target->end;
        root = eraseHelper(root, id, oldS, oldE);
        root = insertHelper(root, id, s, e);
        return true;
    }

    bool conflict(int s, int e) {
        return hasConflictHelper(root, s, e);
    }

    vector<int> overlaps(int s, int e) {
        vector<int> res;
        overlapsHelper(root, s, e, res);
        return res;
    }

    vector<int> at(int t) {
        vector<int> res;
        atHelper(root, t, res);
        return res;
    }

    bool next(int t, int& outId, int& outS, int& outE) {
        IntervalNode* best = nullptr;
        nextHelper(root, t, best);
        if (best != nullptr) {
            outId = best->id;
            outS = best->start;
            outE = best->end;
            return true;
        }
        return false;
    }

    string serialize() {
        if (root == nullptr) return "";
        string out = "";
        serializeHelper(root, out);
        return out;
    }
};

int main(int argc, char* argv[]) {
    if (argc < 3) {
        cerr << "Usage: " << argv[0] << " <input-file> <output-file>\n";
        return 1;
    }

    ifstream fin(argv[1]);
    if (!fin.is_open()) {
        cerr << "Error opening input file: " << argv[1] << "\n";
        return 1;
    }

    ofstream fout(argv[2]);
    if (!fout.is_open()) {
        cerr << "Error opening output file: " << argv[2] << "\n";
        return 1;
    }

    IntervalAVLTree scheduler;

    long long count_add = 0, total_ns_add = 0;
    long long count_remove = 0, total_ns_remove = 0;
    long long count_update = 0, total_ns_update = 0;
    long long count_conflict = 0, total_ns_conflict = 0;
    long long count_overlaps = 0, total_ns_overlaps = 0;
    long long count_at = 0, total_ns_at = 0;
    long long count_next = 0, total_ns_next = 0;

    string line;
    while (getline(fin, line)) {
        if (line.empty()) continue;
        stringstream ss(line);
        string cmd;
        if (!(ss >> cmd)) continue;

        if (cmd == "ADD") {
            int s, e;
            ss >> s >> e;
            auto t1 = chrono::steady_clock::now();
            scheduler.add(s, e);
            auto t2 = chrono::steady_clock::now();
            total_ns_add += chrono::duration_cast<chrono::nanoseconds>(t2 - t1).count();
            count_add++;

            fout << scheduler.serialize() << "\n";
        } else if (cmd == "REMOVE") {
            int id;
            ss >> id;
            auto t1 = chrono::steady_clock::now();
            bool ok = scheduler.remove(id);
            auto t2 = chrono::steady_clock::now();
            total_ns_remove += chrono::duration_cast<chrono::nanoseconds>(t2 - t1).count();
            count_remove++;

            if (ok) {
                fout << scheduler.serialize() << "\n";
            } else {
                fout << "not found\n";
            }
        } else if (cmd == "UPDATE") {
            int id, s, e;
            ss >> id >> s >> e;
            auto t1 = chrono::steady_clock::now();
            bool ok = scheduler.update(id, s, e);
            auto t2 = chrono::steady_clock::now();
            total_ns_update += chrono::duration_cast<chrono::nanoseconds>(t2 - t1).count();
            count_update++;

            if (ok) {
                fout << scheduler.serialize() << "\n";
            } else {
                fout << "not found\n";
            }
        } else if (cmd == "CONFLICT") {
            int s, e;
            ss >> s >> e;
            auto t1 = chrono::steady_clock::now();
            bool hasConf = scheduler.conflict(s, e);
            auto t2 = chrono::steady_clock::now();
            total_ns_conflict += chrono::duration_cast<chrono::nanoseconds>(t2 - t1).count();
            count_conflict++;

            fout << (hasConf ? "yes\n" : "no\n");
        } else if (cmd == "OVERLAPS") {
            int s, e;
            ss >> s >> e;
            auto t1 = chrono::steady_clock::now();
            vector<int> res = scheduler.overlaps(s, e);
            auto t2 = chrono::steady_clock::now();
            total_ns_overlaps += chrono::duration_cast<chrono::nanoseconds>(t2 - t1).count();
            count_overlaps++;

            if (res.empty()) {
                fout << "none\n";
            } else {
                for (size_t i = 0; i < res.size(); ++i) {
                    fout << res[i] << (i + 1 == res.size() ? "" : " ");
                }
                fout << "\n";
            }
        } else if (cmd == "AT") {
            int t;
            ss >> t;
            auto t1 = chrono::steady_clock::now();
            vector<int> res = scheduler.at(t);
            auto t2 = chrono::steady_clock::now();
            total_ns_at += chrono::duration_cast<chrono::nanoseconds>(t2 - t1).count();
            count_at++;

            if (res.empty()) {
                fout << "none\n";
            } else {
                for (size_t i = 0; i < res.size(); ++i) {
                    fout << res[i] << (i + 1 == res.size() ? "" : " ");
                }
                fout << "\n";
            }
        } else if (cmd == "NEXT") {
            int t;
            ss >> t;
            int nid, ns, ne;
            auto t1 = chrono::steady_clock::now();
            bool ok = scheduler.next(t, nid, ns, ne);
            auto t2 = chrono::steady_clock::now();
            total_ns_next += chrono::duration_cast<chrono::nanoseconds>(t2 - t1).count();
            count_next++;

            if (ok) {
                fout << nid << " " << ns << " " << ne << "\n";
            } else {
                fout << "none\n";
            }
        }
    }

    fin.close();
    fout.close();

    cout << "operation,count,total_ns,average_ns\n";
    auto print_row = [](const string& name, long long cnt, long long total) {
        cout << name << "," << cnt << "," << total << ",";
        if (cnt == 0) {
            cout << "N/A\n";
        } else {
            cout << (total / cnt) << "\n";
        }
    };

    print_row("add", count_add, total_ns_add);
    print_row("remove", count_remove, total_ns_remove);
    print_row("update", count_update, total_ns_update);
    print_row("conflict", count_conflict, total_ns_conflict);
    print_row("overlaps", count_overlaps, total_ns_overlaps);
    print_row("at", count_at, total_ns_at);
    print_row("next", count_next, total_ns_next);

    return 0;
}