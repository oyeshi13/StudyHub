Compilation Instructions:
-------------------------
To compile the AVL Tree program:
g++ -O3 -std=c++17 AVLTree.cpp -o AVLTree.exe

To compile the Interval Scheduler program:
g++ -O3 -std=c++17 IntervalScheduler.cpp -o IntervalScheduler.exe


Execution Instructions:
-----------------------
1. AVL Tree:
.\AVLTree.exe <input-file> <output-file>

Example:
.\AVLTree.exe testcase_avl.txt output_avl.txt

2. Interval Scheduler:
.\IntervalScheduler.exe <input-file> <output-file>

Example:
.\IntervalScheduler.exe testcase_basic_interval.txt output_basic.txt
.\IntervalScheduler.exe testcase_large_interval.txt output_large.txt
.\IntervalScheduler.exe testcase_edge_interval.txt output_edge.txt

Timing Report Generation:
-------------------------
The timing metrics are outputted to standard output (stdout) in nanoseconds.
To generate timing_report.txt, run this command in terminal:

cmd /c "echo AVL> timing_report.txt && AVLTree.exe testcase_avl.txt output_avl.txt >> timing_report.txt && echo.>> timing_report.txt && echo Interval Scheduler>> timing_report.txt && IntervalScheduler.exe testcase_large_interval.txt output_large.txt >> timing_report.txt"