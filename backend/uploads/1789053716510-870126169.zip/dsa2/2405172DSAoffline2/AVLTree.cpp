#include <iostream>
#include<bits/stdc++.h>

using namespace std;

class AVLNode {
public:
    int key;
    int height;
    AVLNode* left;
    AVLNode* right;

    AVLNode(int k) {
        key = k;
        height = 1;
        left = nullptr;
        right = nullptr;
    }
};

class AVLTree {
    AVLNode* root;

    int getHeight(AVLNode* node) {
        if (node == nullptr) return 0;
        return node->height;
    }

    int getBalanceFactor(AVLNode* node) {
        if (node == nullptr) return 0;
        return getHeight(node->left) - getHeight(node->right);
    }

    void updateHeight(AVLNode* node) {
        if (node != nullptr) {
            node->height = 1 + max(getHeight(node->left), getHeight(node->right));
        }
    }

    AVLNode* rotateRight(AVLNode* y) {
        AVLNode* x = y->left;
        AVLNode* T2 = x->right;

        x->right = y;
        y->left = T2;

        updateHeight(y);
        updateHeight(x);

        return x;
    }

    AVLNode* rotateLeft(AVLNode* x) {
        AVLNode* y = x->right;
        AVLNode* T2 = y->left;

        y->left = x;
        x->right = T2;

        updateHeight(x);
        updateHeight(y);

        return y;
    }

    AVLNode* insertHelper(AVLNode* node, int key, bool& inserted) {
        if (node == nullptr) {
            inserted = true;
            return new AVLNode(key);
        }

        if (key < node->key) {
            node->left = insertHelper(node->left, key, inserted);
        } else if (key > node->key) {
            node->right = insertHelper(node->right, key, inserted);
        } else {
            inserted = false;
            return node;
        }

        updateHeight(node);
        int bf = getBalanceFactor(node);

        if (bf > 1) {
            if (getBalanceFactor(node->left) >= 0) {
                return rotateRight(node);
            } else {
                node->left = rotateLeft(node->left);
                return rotateRight(node);
            }
        }
        if (bf < -1) {
            if (getBalanceFactor(node->right) <= 0) {
                return rotateLeft(node);
            } else {
                node->right = rotateRight(node->right);
                return rotateLeft(node);
            }
        }

        return node;
    }

    AVLNode* findMin(AVLNode* node) {
        while (node != nullptr && node->left != nullptr) {
            node = node->left;
        }
        return node;
    }

    AVLNode* eraseHelper(AVLNode* node, int key, bool& erased) {
        if (node == nullptr) {
            erased = false;
            return nullptr;
        }

        if (key < node->key) {
            node->left = eraseHelper(node->left, key, erased);
        } else if (key > node->key) {
            node->right = eraseHelper(node->right, key, erased);
        } else {
            erased = true;
            if (node->left == nullptr || node->right == nullptr) {
                AVLNode* temp = (node->left != nullptr) ? node->left : node->right;
                if (temp == nullptr) {
                    temp = node;
                    node = nullptr;
                } else {
                    node->key = temp->key;
                    node->left = temp->left;
                    node->right = temp->right;
                    node->height = temp->height;
                }
                delete temp;
            } else {
                AVLNode* successor = findMin(node->right);
                node->key = successor->key;
                node->right = eraseHelper(node->right, successor->key, erased);
            }
        }

        if (node == nullptr) return nullptr;

        updateHeight(node);
        int bf = getBalanceFactor(node);

        if (bf > 1) {
            if (getBalanceFactor(node->left) >= 0) {
                return rotateRight(node);
            } else {
                node->left = rotateLeft(node->left);
                return rotateRight(node);
            }
        }
        if (bf < -1) {
            if (getBalanceFactor(node->right) <= 0) {
                return rotateLeft(node);
            } else {
                node->right = rotateRight(node->right);
                return rotateLeft(node);
            }
        }

        return node;
    }

    bool findHelper(AVLNode* node, int key) {
        if (node == nullptr) return false;
        if (key == node->key) return true;
        if (key < node->key) return findHelper(node->left, key);
        return findHelper(node->right, key);
    }

    void inOrderHelper(AVLNode* node, vector<int>& res) {
        if (node == nullptr) return;
        inOrderHelper(node->left, res);
        res.push_back(node->key);
        inOrderHelper(node->right, res);
    }

    void serializeHelper(AVLNode* node, string& out) {
        if (node == nullptr) return;
        out += to_string(node->key);
        if (node->left != nullptr || node->right != nullptr) {
            out += "(";
            serializeHelper(node->left, out);
            out += ",";
            serializeHelper(node->right, out);
            out += ")";
        }
    }

    void destroyHelper(AVLNode* node) {
        if (node == nullptr) return;
        destroyHelper(node->left);
        destroyHelper(node->right);
        delete node;
    }

public:
    AVLTree() {
        root = nullptr;
    }

    ~AVLTree() {
        destroyHelper(root);
    }

    bool insert(int key) {
        bool inserted = false;
        root = insertHelper(root, key, inserted);
        return inserted;
    }

    bool erase(int key) {
        bool erased = false;
        root = eraseHelper(root, key, erased);
        return erased;
    }

    bool find(int key) {
        return findHelper(root, key);
    }

    vector<int> traverse() {
        vector<int> res;
        inOrderHelper(root, res);
        return res;
    }

    string serialize() {
        if (root == nullptr) return "";
        string out = "";
        serializeHelper(root, out);
        return out;
    }
};

int main(int argc, char* argv[]) {
    if (argc < 3) {
        cerr << "Usage: " << argv[0] << " <input-file> <output-file>\n";
        return 1;
    }

    ifstream fin(argv[1]);
    if (!fin.is_open()) {
        cerr << "Error opening input file: " << argv[1] << "\n";
        return 1;
    }

    ofstream fout(argv[2]);
    if (!fout.is_open()) {
        cerr << "Error opening output file: " << argv[2] << "\n";
        return 1;
    }

    AVLTree tree;

    long long count_insert = 0, total_ns_insert = 0;
    long long count_delete = 0, total_ns_delete = 0;
    long long count_find = 0, total_ns_find = 0;
    long long count_traverse = 0, total_ns_traverse = 0;

    string line;
    while (getline(fin, line)) {
        if (line.empty()) continue;
        stringstream ss(line);
        char op;
        if (!(ss >> op)) continue;

        if (op == 'I') {
            int key;
            ss >> key;
            auto t1 = chrono::steady_clock::now();
            bool ok = tree.insert(key);
            auto t2 = chrono::steady_clock::now();
            total_ns_insert += chrono::duration_cast<chrono::nanoseconds>(t2 - t1).count();
            count_insert++;

            if (ok) {
                fout << tree.serialize() << "\n";
            } else {
                fout << "duplicate\n";
            }
        } else if (op == 'D') {
            int key;
            ss >> key;
            auto t1 = chrono::steady_clock::now();
            bool ok = tree.erase(key);
            auto t2 = chrono::steady_clock::now();
            total_ns_delete += chrono::duration_cast<chrono::nanoseconds>(t2 - t1).count();
            count_delete++;

            if (ok) {
                fout << tree.serialize() << "\n";
            } else {
                fout << "not found\n";
            }
        } else if (op == 'F') {
            int key;
            ss >> key;
            auto t1 = chrono::steady_clock::now();
            bool ok = tree.find(key);
            auto t2 = chrono::steady_clock::now();
            total_ns_find += chrono::duration_cast<chrono::nanoseconds>(t2 - t1).count();
            count_find++;

            if (ok) {
                fout << "found\n";
            } else {
                fout << "not found\n";
            }
        } else if (op == 'T') {
            auto t1 = chrono::steady_clock::now();
            vector<int> res = tree.traverse();
            auto t2 = chrono::steady_clock::now();
            total_ns_traverse += chrono::duration_cast<chrono::nanoseconds>(t2 - t1).count();
            count_traverse++;

            for (size_t i = 0; i < res.size(); ++i) {
                fout << res[i] << (i + 1 == res.size() ? "" : " ");
            }
            fout << "\n";
        }
    }

    fin.close();
    fout.close();

    cout << "operation,count,total_ns,average_ns\n";
    auto print_row = [](const string& name, long long cnt, long long total) {
        cout << name << "," << cnt << "," << total << ",";
        if (cnt == 0) {
            cout << "N/A\n";
        } else {
            cout << (total / cnt) << "\n";
        }
    };

    print_row("insert", count_insert, total_ns_insert);
    print_row("delete", count_delete, total_ns_delete);
    print_row("find", count_find, total_ns_find);
    print_row("traverse", count_traverse, total_ns_traverse);

    return 0;
}