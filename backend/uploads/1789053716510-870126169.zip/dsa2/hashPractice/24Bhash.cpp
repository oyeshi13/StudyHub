#include<iostream>
#include<bits/stdc++.h>
using namespace std;
bool primeCheck(int n){
    if(n<=1) return false;
    if(n==2) return true;
    int c=0;
    for(int i=2;i*i<=n;i++){
        if (n%i==0)
        {c++;
        break;
        }
    }
    if(c==0) return true;
    return false;
}
int getNextPrime(int n){
    while(!primeCheck(n)){
        n++;
    }
    return n;
}

int Hash1(string str,int n){
    long long val=0;
    for(int i=1;i<=str.length();i++){
        val+=(str[i-1]*i)%13;
    }
    return val%13;
}

class Node{
    public:
     string key;
     int val;
     Node* next;
     double weight;

};
class chainHash{
    public:
    vector<Node*> table;
    int size,elements,insertions,collisions;
    bool useHash1;
    chainHash(int size,bool useHash1){
        this->size=size;
        elements=0;
        insertions=0;
        collisions=0;
        this->useHash1=useHash1;
        table.assign(size,NULL);
    }
     double weight(string k){
       int l=k.length();
       return ((k[0]+k[l-1])%100)/100.00;
    }
    void insert(string key,int val){
       
        int idx;
        if(useHash1){
            idx=Hash1(key,size);

        }
        else
               idx=Hash1(key,size);

        Node* curr=table[idx];
        while(curr!=NULL){
            if(curr->key==key)
            return;
            curr=curr->next;

        }
        if(table[idx]!=NULL)
        collisions++;

        Node* newNode=new Node();
        newNode->key=key;
        newNode->val=val;
        newNode->weight=weight(key);
        newNode->next=NULL;
       
       
            if(table[idx]==NULL||newNode->weight>table[idx]->weight){
                newNode->next=table[idx];
                table[idx]=newNode;
            }
            else{
                Node* cur=table[idx];
                while(cur->next!=NULL&&cur->next->weight>=newNode->weight){
                    cur=cur->next;
                }
                newNode->next=cur->next;
                cur->next=newNode;
            }
          
     
        elements++;
        insertions++;
    }

    
};


int main() {
    vector<string> words(12);
    
    for (int i = 0; i < 12; i++) {
        cin >> words[i];
    }

    chainHash chain1(13, true);  
    
    // Fixed: Loop stops at 12
    for (int i = 0; i < 12; i++) {
        string curr_word = words[i];
        int curr_val = i + 1; 
        chain1.insert(curr_word, curr_val);
    }
    
    vector<int> emptyBuckets;
    cout << "--------------------------------------------" << endl;
    cout << "    Bucket Chain (head -> tail)            " << endl;
    cout << "--------------------------------------------" << endl;
    
    for (int i = 0; i < 13; i++) {
        if (chain1.table[i] == NULL) {
            emptyBuckets.push_back(i);
        } else {
            cout << i << " ";
            Node* curr = chain1.table[i];
            
            while (curr != NULL) {
                // Fixed: Print curr->key instead of the pointer
                cout << curr->key << " (" << curr->weight << ")";
                if (curr->next != NULL) {
                    cout << " -> ";
                }
                // Fixed: Move to the next node to prevent infinite loops
                curr = curr->next;
            }
            cout << endl;
        }
    }
    
    for (int i = 0; i < emptyBuckets.size(); i++) {
        cout << emptyBuckets[i];
        if (i != emptyBuckets.size() - 1) {
            cout << ",";
        }
    }
    cout << " (empty)" << endl;
    
    return 0;
}