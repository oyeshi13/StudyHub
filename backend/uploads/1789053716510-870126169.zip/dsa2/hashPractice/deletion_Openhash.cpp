#include<iostream>
#include<bits/stdc++.h>
using namespace std;
bool primeCheck(int n){
    if(n<=1) return false;
    if(n==2) return true;
    int c=0;
    for(int i=2;i*i<=n;i++){
        if (n%i==0)
        {c++;
        break;
        }
    }
    if(c==0) return true;
    return false;
}
int getNextPrime(int n){
    while(!primeCheck(n)){
        n++;
    }
    return n;
}

int Hash1(string str,int n){
    long long val=0;
    for(int i=0;i<str.length();i++){
        val=(val*31+str[i])%n;
    }
    return val;
}
int Hash2(string str,int n){
    long long val=5381;
    for(int i=0;i<str.length();i++){
        val=((val<<5)+val+str[i])%n;
        
    }
    return val;
}
int auxHash(string str,int n){
    long long val = 0;
    for (int i = 0; i < str.length(); i++) {
        val = (val * 37 + str[i]);
    }
    int h = val % n;
    return h == 0 ? 1 : h;
}
class Node{
    public:
     string key;
     int val;
     Node* next;

};
class chainHash{
    public:
    vector<Node*> table;
    int size,elements,insertions,collisions;
    bool useHash1;
    chainHash(int size,bool useHash1){
        this->size=size;
        elements=0;
        insertions=0;
        collisions=0;
        this->useHash1=useHash1;
        table.assign(size,NULL);
    }
    void resize(int new_size) {
        vector<Node*> old_table = table; 
        int old_size =size; 
        
        size = new_size;
        table.assign(size, NULL); 
        
        elements = 0; 
        insertions = 0;
        collisions = 0;
        
        for (int i = 0; i < old_size; i++) {
            Node* curr = old_table[i];
            while (curr != NULL) { 
                insert(curr->key, curr->val); 
                Node* temp = curr; 
                curr = curr->next; 
                delete temp; 
            }
        }
    }
    void insert(string key,int val){
        if(float(elements)/size>0.5 && insertions>=elements/2)
        {int new_size=getNextPrime(size*2+1);
        resize(new_size);
    }
        int idx;
        if(useHash1){
            idx=Hash1(key,size);

        }
        else
               idx=Hash2(key,size);

        Node* curr=table[idx];
        while(curr!=NULL){
            if(curr->key==key)
            return;
            curr=curr->next;

        }
        if(table[idx]!=NULL)
        collisions++;

        Node* newNode=new Node();
        newNode->key=key;
        newNode->val=val;
        newNode->next=table[idx];
        table[idx]=newNode;
        elements++;
        insertions++;
    }

    int search(string key,int& hits){
        int idx;
        if (useHash1) {
            idx = Hash1(key,size);
        } else {
            idx = Hash2(key,size);
        }

        Node* curr = table[idx];
        while (curr != NULL) { 
            hits++; 
            if (curr->key == key) {
                return curr->val; 
            }
            curr = curr->next; 
        }
        return -1;
    }
};
class HashNode{
    public:
    string key;
    int val;
    bool isOccupied;
    bool isDeleted;
    HashNode(){
        isOccupied = false;
        isDeleted = false;
    }

};
class openHash {
public:
    vector<HashNode> table;
    int size;
    int elements;
    int insertions;
    int collisions;
    int probingType; 
    int C1;
    int C2;
    bool useHash1;

    openHash(int size, bool useHash1, int probingType) {
        this->size = size;
        this->useHash1 = useHash1;
        this->probingType = probingType;
        elements = 0;
        insertions = 0;
        collisions = 0;
        C1 = 3;
        C2 = 5;
        table.resize(size);
    }
    bool remove(string key){
        int hash_val;
    if (useHash1) {
        hash_val = Hash1(key, size);
    } else {
        hash_val = Hash2(key, size);
    }
    int aux_val = auxHash(key, size);
    int i = 0;
    int idx = hash_val;
    while(table[idx].isOccupied){
        if(table[idx].key==key && table[idx].isDeleted==false){
            table[idx].isDeleted=true;
            elements--;
            return true;
        }
        i++;
        if(probingType==1){
            idx=(hash_val + i * aux_val) % size;
        }
        else if(probingType==2){
            idx = (hash_val + C1 * i * aux_val + C2 * i * i) % size;
        }
    }
    return false;
    }
    void insert(string key, int val) {
        if ((float)elements / size > 0.5 && insertions >= elements / 2) {
            int new_size = getNextPrime(size * 2 + 1);
            resize(new_size);
        }

        int hash_val;
        if (useHash1) {
            hash_val = Hash1(key, size);
        } else {
            hash_val = Hash2(key, size);
        }

        int aux_val = auxHash(key, size);
        int i = 0;
        int idx = hash_val;

        while (table[idx].isOccupied && !table[idx].isDeleted) {
            if (table[idx].key == key) {
                return;
            }

            collisions++;
            i++;

            if (probingType == 1) {
                idx = (hash_val + i * aux_val) % size;
            } else {
                idx = (hash_val + C1 * i * aux_val + C2 * i * i) % size;
            }
        }

        table[idx].key = key;
        table[idx].val = val;
        table[idx].isOccupied = true;
        table[idx].isDeleted = false;

        elements++;
        insertions++;
    }
void resize(int new_size) {
        vector<HashNode> old_table = table;
        int old_size = size;

        size = new_size;
        table.clear();
        table.resize(size);

        elements = 0;
        insertions = 0;
        collisions = 0;
        for (int j = 0; j < old_size; j++) {
            if (old_table[j].isOccupied && !old_table[j].isDeleted) {
                insert(old_table[j].key, old_table[j].val);
            }
        }
    }
int search(string key, int& hits) {
        int hash_val;
        if (useHash1) {
            hash_val = Hash1(key, size);
        } else {
            hash_val = Hash2(key, size);
        }

        int aux_val = auxHash(key, size);
        int i = 0;
        int idx = hash_val;

        while (table[idx].isOccupied) {
            hits++;
            if (!table[idx].isDeleted && table[idx].key == key) {
                return table[idx].val;
            }

            i++;

            if (probingType == 1) {
                idx = (hash_val + i * aux_val) % size;
            } else {
                idx = (hash_val + C1 * i * aux_val + C2 * i * i) % size;
            }

            if (i > size) {
                break;
            }
        }
        return -1;
    }
};

string generateRandomWord(int length) {
    string word = "";
    for (int i = 0; i < length; i++) {
        word += (char)('a' + rand() % 26);
    }
    return word;
}
int main() {

   srand(time(0));
    
    int N = 10000;
    int length = 10;

    vector<string> words;
    words.resize(N);
    
    for (int i = 0; i < N; i++) {
        words[i] = generateRandomWord(length);
    }

    chainHash chain1(13, true);  
    chainHash chain2(13, false); 
    
    openHash dh1(13, true, 1);
    openHash dh2(13, false, 1);
    
    openHash cp1(13, true, 2);
    openHash cp2(13, false, 2);
    
    for (int i = 0; i < N; i++) {
        string curr_word = words[i];
        int curr_val = i + 1; 
        
        chain1.insert(curr_word, curr_val);
        chain2.insert(curr_word, curr_val);
        
        dh1.insert(curr_word, curr_val);
        dh2.insert(curr_word, curr_val);
        
        cp1.insert(curr_word, curr_val);
        cp2.insert(curr_word, curr_val);
    }
    

    
   
    if(dh1.remove("fabiha")){
        cout<<"deleted"<<endl;
    }
    else
    cout<<"doesnt exist"<<endl;
}