#include<bits/stdc++.h>
using namespace std;
class Edge{
    public:
    int cap,flow,rev,to;
    Edge(int cap,int to,int flow,int rev){
        this->cap=cap;
        this->to=to;
        this->flow=flow;
        this->rev=rev;
    }
};
 class graph{
   public:
    int v;
    vector<vector<Edge>> adj;
    graph(int v){
        this->v=v;
        adj.resize(v);

    }
    void addEdge(int u,int v,int cap){
        Edge forward(cap,v,0,int(adj[v].size()));
         Edge backward(0,u,0,int(adj[u].size()));
         adj[u].push_back(forward);
         adj[v].push_back(backward);
    }
    bool bfs(int source,int sink,vector<int> &parent, vector<int> &pedge){
        for(int i=0;i<v;i++){
            parent[i]=-1;
            pedge[i]=-1;
        }
        queue<int> q;
        q.push(source);
        while(!q.empty()){
            int u=q.front();
            q.pop();
            if(u==sink)
            return true;
            for(int i=0;i<adj[u].size();i++){
                Edge e=adj[u][i];
                int rcap=e.cap-e.flow;
                if(parent[e.to]==-1&&e.to!=source&&rcap>0){
                    parent[e.to]=u;
                    pedge[e.to]=i;
                    q.push(e.to);
                }
            }
        }
        return false;
    }
    int maxFlow(int source,int sink){
        int INF=1e9;
        int maxFlow=0;
        vector<int> parent(v);
        vector<int> pedge(v);
        while (bfs(source, sink, parent, pedge)) {
            int pathFlow = INF;

            for (int cur = sink; cur != source; cur = parent[cur]) {
                int u = parent[cur];
                int edgeIdx = pedge[cur];
                pathFlow = min(pathFlow, adj[u][edgeIdx].cap - adj[u][edgeIdx].flow);
            }

            for (int cur = sink; cur != source; cur= parent[cur]) {
                int u = parent[cur];
                int edgeIdx = pedge[cur];

                adj[u][edgeIdx].flow += pathFlow;

                int revIdx = adj[u][edgeIdx].rev;
                adj[cur][revIdx].flow -= pathFlow;
            }

            maxFlow += pathFlow;
        }
        return maxFlow;
    }
    

 };
 int main(){
    int N, M;
    cin>>N>>M;

   
    graph g(N+1);
 vector<vector<int>> ip(N+1,vector<int>(3));

    for (int i = 0; i < M; i++) {
        int u, v, w;
        cin >> u >> v >> w;
        g.addEdge(u, v, w);
        ip[i][0]=u;
         ip[i][1]=v;
          ip[i][2]=w;
    }
 
    int source = 1;
    int sink = N ;

    int imaxFlow= g.maxFlow(source, sink);
    int p;
 cin>>p;
 graph g1(p+1+N);
 vector<vector<int>> pp(p+1,vector<int>(3));
  for (int i = 1; i<=p; i++) {
        int u, v, w;
        cin >> u >> v >> w;
      pp[i][0]=u;
       pp[i][1]=v;
        pp[i][2]=w;
       
    }
    for(int i=1;i<ip.size();i++){
        g1.addEdge(ip[i][0],ip[i][1],ip[i][2]);
    }
     for (int i = 1; i<=p; i++) {

        g1.addEdge(pp[i][0],pp[i][1],pp[i][2]);
        int fmaxFlow= g1.maxFlow(source, sink);
        if(fmaxFlow>imaxFlow){
            cout<<i<<endl;
        }

     }
       
    
 

    return 0;
}
 