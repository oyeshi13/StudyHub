#include<bits/stdc++.h>
using namespace std;
class Edge{
    public:
    int cap,flow,rev,to;
    Edge(int cap,int to,int flow,int rev){
        this->cap=cap;
        this->to=to;
        this->flow=flow;
        this->rev=rev;
    }
};
 class graph{
   public:
    int v;
    vector<vector<Edge>> adj;
    graph(int v){
        this->v=v;
        adj.resize(v);

    }
    void addEdge(int u,int v,int cap){
        Edge forward(cap,v,0,int(adj[v].size()));
         Edge backward(0,u,0,int(adj[u].size()));
         adj[u].push_back(forward);
         adj[v].push_back(backward);
    }
    bool bfs(int source,int sink,vector<int> &parent, vector<int> &pedge){
        for(int i=0;i<v;i++){
            parent[i]=-1;
            pedge[i]=-1;
        }
        queue<int> q;
        q.push(source);
        while(!q.empty()){
            int u=q.front();
            q.pop();
            if(u==sink)
            return true;
            for(int i=0;i<adj[u].size();i++){
                Edge e=adj[u][i];
                int rcap=e.cap-e.flow;
                if(parent[e.to]==-1&&e.to!=source&&rcap>0){
                    parent[e.to]=u;
                    pedge[e.to]=i;
                    q.push(e.to);
                }
            }
        }
        return false;
    }
    int maxFlow(int source,int sink){
        int INF=1e9;
        int maxFlow=0;
        vector<int> parent(v);
        vector<int> pedge(v);
        int c=0;
        while (bfs(source, sink, parent, pedge)) {
            int pathFlow = INF;

            for (int cur = sink; cur != source; cur = parent[cur]) {
                int u = parent[cur];
                int edgeIdx = pedge[cur];
                pathFlow = min(pathFlow, adj[u][edgeIdx].cap - adj[u][edgeIdx].flow);
            }

            for (int cur = sink; cur != source; cur= parent[cur]) {
                int u = parent[cur];
                int edgeIdx = pedge[cur];

                adj[u][edgeIdx].flow += pathFlow;

                int revIdx = adj[u][edgeIdx].rev;
                adj[cur][revIdx].flow -= pathFlow;
            }

            maxFlow += pathFlow;
            c++;
        }
        return c;
    }
    

 };
 int main(){
    int N, M;
    cin>>N>>M;
    int s,t;
    cin>>s>>t;

   
    graph g(N);


    for (int i = 0; i < M; i++) {
        int u, v;
        cin >> u >> v ;
        g.addEdge(u, v, 1);
    }

   
 if(g.maxFlow(s,t)!=0)
    cout << g.maxFlow(s,t) <<endl;
    else
    cout<<-1<<endl;

    return 0;
}
 