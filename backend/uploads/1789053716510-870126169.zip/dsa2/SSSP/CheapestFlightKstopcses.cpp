#include<bits/stdc++.h>
using namespace std;

// cannot use for neg weighted edges
class Edge {
public: 
    int v;
    int w;
    Edge(int v, int w) {
        this->v = v;
        this->w = w;
    }
};

void dijkstra(int src, vector<vector<Edge>> g, int n, int dst, int k) {
    int max_flights = k + 1; // k stops = maximum (k + 1) flights

    // dist[node][flights_taken]
    vector<vector<long long>> dist(n, vector<long long>(max_flights + 1, INT64_MAX));
    dist[src][0] = 0;

    // pq stores: {cost, {node, flights_taken}}
    priority_queue<pair<long long, pair<int, int>>, 
                   vector<pair<long long, pair<int, int>>>, 
                   greater<pair<long long, pair<int, int>>>> pq;

    pq.push({0, {src, 0}});

    while (pq.size() > 0) {
        long long d = pq.top().first;
        int u = pq.top().second.first;
        int flights = pq.top().second.second;
        pq.pop();

        if (d > dist[u][flights]) continue;
        if (flights == max_flights) continue; // max flight count reached

        for (Edge e : g[u]) { // edge relaxation
            if (dist[e.v][flights + 1] > dist[u][flights] + e.w) {
                dist[e.v][flights + 1] = dist[u][flights] + e.w;
                pq.push({dist[e.v][flights + 1], {e.v, flights + 1}});
            }
        }
    }

    // k+1 টি ফ্লাইট পর্যন্ত সেরা ডিস্ট্যান্স বের করা
    long long ans = INT64_MAX;
    for (int i = 1; i <= max_flights; i++) {
        ans = min(ans, dist[dst][i]);
    }

    if (ans >= INT64_MAX / 2) {
        cout << -1 << endl;
    } else {
        cout << ans << endl;
    }
}

int main() {
    int n, m, k, src, dst;
    if (!(cin >> n >> m >> k >> src >> dst)) return 0;

    vector<vector<Edge>> g(n);
    for (int i = 0; i < m; i++) {
        int a, b, c;
        cin >> a >> b >> c;
        g[a].push_back(Edge(b, c));
    }

    dijkstra(src, g, n, dst, k);

    return 0;
}