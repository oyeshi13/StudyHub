#include<bits/stdc++.h>
using namespace std;

// cannot use for neg weighted edges
class Edge {
public: 
    int v;
    int w;
    Edge(int v, int w) {
        this->v = v;
        this->w = w;
    }
};

void dijkstra(int src, vector<vector<Edge>> g, int v, int k) {
    // dist[node][coupon_used][flight_count]
    vector<vector<vector<long long>>> dist(v, vector<vector<long long>>(2, vector<long long>(k + 1, LLONG_MAX)));
    dist[src][0][0] = 0;

    // pq stores: {cost, {node, {coupon_used, flights_taken}}}
    priority_queue<pair<long long, pair<int, pair<int, int>>>, 
                   vector<pair<long long, pair<int, pair<int, int>>>>, 
                   greater<pair<long long, pair<int, pair<int, int>>>>> pq;

    pq.push({0, {src, {0, 0}}});

    while (pq.size() > 0) {
        long long d = pq.top().first;
        int u = pq.top().second.first;
        int disc = pq.top().second.second.first;
        int flights = pq.top().second.second.second;
        pq.pop();

        if (d > dist[u][disc][flights]) continue;
        if (flights == k) continue; // cannot take more than k flights

        for (Edge e : g[u]) { // edge relaxation
            if (disc == 0) {
                // 1. Without using coupon
                if (dist[e.v][0][flights + 1] > dist[u][0][flights] + e.w) {
                    dist[e.v][0][flights + 1] = dist[u][0][flights] + e.w;
                    pq.push({dist[e.v][0][flights + 1], {e.v, {0, flights + 1}}});
                }
                // 2. Use coupon on this edge
                if (dist[e.v][1][flights + 1] > dist[u][0][flights] + e.w / 2) {
                    dist[e.v][1][flights + 1] = dist[u][0][flights] + e.w / 2;
                    pq.push({dist[e.v][1][flights + 1], {e.v, {1, flights + 1}}});
                }
            }
            else {
                // 3. Coupon already used in a previous edge
                if (dist[e.v][1][flights + 1] > dist[u][1][flights] + e.w) {
                    dist[e.v][1][flights + 1] = dist[u][1][flights] + e.w;
                    pq.push({dist[e.v][1][flights + 1], {e.v, {1, flights + 1}}});
                }
            }
        }
    }

    long long min_cost = LLONG_MAX;
    for (int i = 1; i <= k; i++) {
        min_cost = min(min_cost, dist[v - 1][0][i]);
        min_cost = min(min_cost, dist[v - 1][1][i]);
    }

    if (min_cost == LLONG_MAX) {
        cout << "Not possible" << endl;
    } else {
        cout << min_cost << endl;
    }
}

int main() {
    int n, m, k;
    if (!(cin >> n >> m >> k)) return 0;

    vector<vector<Edge>> g(n + 1);
    for (int i = 0; i < m; i++) {
        int a, b, c;
        cin >> a >> b >> c;
        g[a].push_back(Edge(b, c));
    }

    dijkstra(1, g, n + 1, k);

    return 0;
}