#include<bits/stdc++.h>
using namespace std;

// cannot use for neg weighted edges
class Edge {
public: 
    int v;
    int w;
    Edge(int v, int w) {
        this->v = v;
        this->w = w;
    }
};

void dijkstra(int src, vector<vector<Edge>> g, int v) {
    // dist[node][coupons_used] -> coupons_used can be 0, 1, or 2
    vector<vector<long long>> dist(v, vector<long long>(3, LLONG_MAX));
    dist[src][0] = 0;

    // pq stores: {cost, {node, coupons_used}}
    priority_queue<pair<long long, pair<int, int>>, 
                   vector<pair<long long, pair<int, int>>>, 
                   greater<pair<long long, pair<int, int>>>> pq;

    pq.push({0, {src, 0}});

    while (pq.size() > 0) {
        long long d = pq.top().first;
        int u = pq.top().second.first;
        int disc = pq.top().second.second; // number of coupons used so far (0, 1, or 2)
        pq.pop();

        if (d > dist[u][disc]) continue;

        for (Edge e : g[u]) { // edge relaxation
            // Option 1: Do not use any coupon on this flight
            if (dist[e.v][disc] > dist[u][disc] + e.w) {
                dist[e.v][disc] = dist[u][disc] + e.w;
                pq.push({dist[e.v][disc], {e.v, disc}});
            }

            // Option 2: Use 1 coupon on this flight (if we still have coupons remaining)
            if (disc < 2) {
                if (dist[e.v][disc + 1] > dist[u][disc] + e.w / 2) {
                    dist[e.v][disc + 1] = dist[u][disc] + e.w / 2;
                    pq.push({dist[e.v][disc + 1], {e.v, disc + 1}});
                }
            }
        }
    }

    // Minimum cost to reach target node (v-1) with 0, 1, or 2 coupons used
    long long ans = min({dist[v - 1][0], dist[v - 1][1], dist[v - 1][2]});
    
    cout << ans << endl;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int n, m;
    if (!(cin >> n >> m)) return 0;

    vector<vector<Edge>> g(n + 1);
    for (int i = 0; i < m; i++) {
        int a, b, c;
        cin >> a >> b >> c;
        g[a].push_back(Edge(b, c));
    }

    dijkstra(1, g, n + 1);

    return 0;
}