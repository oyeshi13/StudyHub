#include<bits/stdc++.h>
using namespace std;

// cant use for neg weighted edges
class Edge {
public: 
    int v;
    int w;
    Edge(int v, int w) {
        this->v = v;
        this->w = w;
    }
};

void dijkstra(int src, vector<vector<Edge>>& g, int v, int f, int k, vector<int>& cap) {
    vector<int> dist(v, INT_MAX);
    dist[src] = 0;
    
    // Min-priority queue: {distance, node}
    priority_queue<pair<int,int>, vector<pair<int,int>>, greater<pair<int,int>>> pq;
    pq.push({0, src});
    
    while(pq.size() > 0) {
        int d = pq.top().first;
        int u = pq.top().second;
        pq.pop();
        
        if (d > dist[u]) continue;
        
        for(Edge e : g[u]) { // edge relaxation
            if(dist[e.v] > dist[u] + e.w) {
                dist[e.v] = dist[u] + e.w;      
                pq.push({dist[e.v], e.v});
            }
        }
    }
    
    // {Total Cost, Capacity} পেয়ার ভেক্টর বানানো যেন সর্ট করলেও ক্যাপাসিটি না হারিয়ে যায়
    vector<pair<int, int>> labs;
    for(int i = 1; i < v; i++) {
        if(dist[i] != INT_MAX) {
            labs.push_back({dist[i] + f, cap[i]});
        }
    }
    
    // কস্ট অনুযায়ী ছোট থেকে বড় সর্ট করা
    sort(labs.begin(), labs.end());
    
    // স্টুডেন্টদের অ্যাসাইন করা
    vector<int> st(k + 1, -1);
    int idx = 0;
    
    for(int i = 1; i <= k; i++) {
        // যতক্ষণ কারেন্ট ল্যাবের ক্যাপাসিটি শেষ, পরের ল্যাবে যাও
        while(idx < labs.size() && labs[idx].second == 0) {
            idx++;
        }
        
        if(idx < labs.size()) {
            st[i] = labs[idx].first;
            labs[idx].second--; // ল্যাবের ক্যাপাসিটি ১ কমলো
        } else {
            st[i] = -1; // কোনো খালি ল্যাব না থাকলে -১
        }
    }
    
    // আউটপুট প্রিন্ট
    for(int i = 1; i <= k; i++) {
        cout << st[i] << (i == k ? "" : " ");
    }
    cout << endl;
}

int main() {
    int n, m, f;
    if (!(cin >> n >> m >> f)) return 0;
    
    vector<int> cap(n + 1);
    for(int i = 1; i <= n; i++) {
        cin >> cap[i];
    }
    
    vector<vector<Edge>> g(n + 1);
    for(int i = 0; i < m; i++) {
        int u, v, w;
        cin >> u >> v >> w;
        // রোডগুলো bidirectional (উভয়মুখী)
        g[u].push_back(Edge(v, w));
        g[v].push_back(Edge(u, w));
    }
    
    int k;
    cin >> k;
    
    dijkstra(1, g, n + 1, f, k, cap);
    
    return 0;
}