#include<bits\stdc++.h>
using namespace std;
vector<vector<int>> all;
//cant use for neg weighted edges
class Edge{
    public: 
    int v;
    int w;
    Edge(int v,int w){
        this->v=v;
        this->w=w;
}
};
void dijkstra(int src,vector<vector<Edge>> g,int v){
    vector<int> dist(v,INT_MAX);
    dist[src]=0;
   // priority_queue<int> pq; priotorised on maximum values
   //  priority_queue<int,vector<int>,greater<int>> pq; reversed priority queue,min values come first
    priority_queue<pair<int,int>,vector<pair<int,int>>,greater<pair<int,int>>> pq;//each operation in pq is O(log(v))
    pq.push({0,src});
    while(pq.size()>0){
        int u=pq.top().second;
        pq.pop();
    for(Edge e:g[u]){//edge relaxaion
        if(dist[e.v]>dist[u]+e.w){
            dist[e.v]=dist[u]+e.w;      //O((E+V)log(V)),Emax(directed)=v(v-1),Emax(idirected)=v(v-1)/2,E can be replaced with v^2.so vlogv can be ingored,and it is O(ElogV) 
            //also can be written as O(ElogE)
            pq.push({dist[e.v],e.v});
        }
   
    }
    

 }
for(int i=1;i<v;i++){
       all[src].push_back(dist[i]);
    }
  /*  for(int i=1;i<dist.size();i++){
        cout<<dist[i]<<" ";
    }*/
    cout<<endl;
    

}
int main(){
   int n,m,k;
   cin>>n>>m>>k;
   vector<vector<Edge>> g(n+1);
   vector<int> emg(k);
   for(int i=0;i<k;i++){
    cin>>emg[i];
   }
   for(int i=0;i<m;i++){
    int u,v,w;
    cin>>u>>v>>w;
    g[u].push_back(Edge(v,w));
   }
   all.resize(n+1);
   for(int i=1;i<=n;i++){
    dijkstra(i,g,n+1);
   }
 /*  for(int i=1;i<all.size();i++){
    for(int j=0;j<all[i].size();j++ ){
        cout<<all[i][j]<<" ";
    }
    cout<<endl;
   }*/
   for(int i=1;i<all.size();i++){
    int min=all[i][emg[0]-1];
    for(int j=1;j<emg.size();j++){
       if(min>all[i][emg[j]-1])
       min=all[i][emg[j]-1];
    }
    if(min==INT_MAX)
    cout<<-1<<endl;
    else
    cout<<min<<endl;
   }

}
