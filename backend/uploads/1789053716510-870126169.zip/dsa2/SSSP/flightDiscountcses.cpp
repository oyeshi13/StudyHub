#include<bits\stdc++.h>
using namespace std;
class Edge{
    public: 
    long long v;
    long long w;
    Edge(long long v,long long w){
        this->v=v;
        this->w=w;
}

};
void dijkstra(int src,vector<vector<Edge>> g,long long v){
    vector<vector<long long>> dist(v,vector<long long>(2,LLONG_MAX));
    dist[src][0]=0;
   // priority_queue<int> pq; priotorised on maximum values
   //  priority_queue<int,vector<int>,greater<int>> pq; reversed priority queue,min values come first
    priority_queue<pair<long long,pair<long long,int>>,vector<pair<long long,pair<long long,int>>>,greater<pair<long long,pair<long long,int>>>> pq;
    pq.push({0,{src,0}});
    while(pq.size()>0){
        long long d = pq.top().first;
        long long u=pq.top().second.first;
        long long discount=pq.top().second.second;
        pq.pop();
        if (d > dist[u][discount]) continue;
    for(Edge e:g[u]){//edge relaxaion
        if(discount==0){
        if(dist[e.v][0]>dist[u][0]+e.w){
            dist[e.v][0]=dist[u][0]+e.w;
            pq.push({dist[e.v][0],{(int)e.v,0}});
        }
         if(dist[e.v][1]>dist[u][0]+e.w/2){
            dist[e.v][1]=dist[u][0]+e.w/2;
            pq.push({dist[e.v][1],{(int)e.v,1}});
        }
    }
    else if(discount==1){
         if(dist[e.v][1]>dist[u][1]+e.w){
            dist[e.v][1]=dist[u][1]+e.w;
            pq.push({dist[e.v][1],{(int)e.v,1}});
        }
    }
    

 }


}
 cout<<dist[v-1][1]<<endl;
}
int main(){
     long long n,m;
    cout<<"enter number of cities and flight connections: "<<endl;
    cin>>n>>m;
     vector<vector<Edge>> g(n+1);
    for(int i=0;i<m;i++){
       long long u,v,w;
        cin>>u>>v>>w;
        Edge e(v,w);
        g[u].push_back(e);
       
    }
    dijkstra(1,g,n+1);
}