#include<bits\stdc++.h>
using namespace std;
//cant use for neg weighted edges
class Edge{
    public: 
    int v;
    int w;
    int t;
    Edge(int v,int w,int t){
        this->v=v;
        this->w=w;
        this->t=t;
}
};
void dijkstra(int src,vector<vector<Edge>> g,int v,int d,int k){
    vector<int> dist(v,INT_MAX);
    vector<int> ttime(v,0);
    vector<int> par(v,-1);
    dist[src]=0;
   // priority_queue<int> pq; priotorised on maximum values
   //  priority_queue<int,vector<int>,greater<int>> pq; reversed priority queue,min values come first
    priority_queue<pair<int,int>,vector<pair<int,int>>,greater<pair<int,int>>> pq;//each operation in pq is O(log(v))
    pq.push({0,src});
    while(pq.size()>0){
        int cost = pq.top().first;
        int u=pq.top().second;
        pq.pop();
    if (cost> dist[u]) continue;
        if (u == d) break;        
        
       
    for(Edge e:g[u]){//edge relaxaion
        int next_time=e.t;
        if(e.v!=d)
        next_time++;
        if(dist[e.v]>dist[u]+e.w+next_time*k){
            dist[e.v]=dist[u]+e.w+next_time*k;      //O((E+V)log(V)),Emax(directed)=v(v-1),Emax(idirected)=v(v-1)/2,E can be replaced with v^2.so vlogv can be ingored,and it is O(ElogV) 
            //also can be written as O(ElogE)
            pq.push({dist[e.v],e.v});
            ttime[e.v]=ttime[u]+next_time;
            par[e.v]=u;
        }
   
    }
    

 }
 if(dist[d]==INT_MAX){
    cout<<"Impossible"<<endl;
    return;
 }
 vector<int> path;
 int cur=d;
 while (cur!=-1)
 {
    path.push_back(cur);
    cur=par[cur];
 }
 reverse(path.begin(),path.end());
for(int i=0;i<path.size();i++){
        cout<<path[i]<<" ";
        if(i<path.size()-1)
        cout<<"->";
    }
    cout<<endl;
    cout << " " << ttime[d] << " " << dist[d] << endl;

}
int main(){
    int n,x,k;
    cin>>k>>n>>x;
    vector<vector<Edge>> g(n+1);
    for(int i=0;i<x;i++){
        int u,v,t,c;
        cin>>u>>v>>t>>c;
        g[u].push_back(Edge(v,c,t));
    }
    int s,d;
    cin>>s>>d;
    dijkstra(s,g,n+1,d,k);
}

