//for neg weighted edges
//doesnt work for neg weighted cycle
//DP algo
#include<bits/stdc++.h>
using namespace std;
class Edge{
    public:
     int v;
     int w;
     Edge(int v,int w){
        this->v=v;
        this->w=w;

     }
};
void bellmanFord(int src,vector<vector<Edge>> g,int v){
    vector<int> dist(v,INT_MAX);
    dist[src]=0;
    for(int i=0;i<v;i++){
        for(int u=0;u<v;u++){//v-1 iterations because highest possible number of edge to reach ith node is always i-1
           if(dist[u] == INT_MAX) continue;
            for(Edge e:g[u]){
                if(dist[e.v]>dist[u]+e.w){
                    dist[e.v]=dist[u]+e.w;
                }
            }
        }
    }
    for(int i=0;i<v;i++){
        cout<<dist[i]<<" ";
    }
    cout<<endl;
}
int main(){
    int v=5;
    vector<vector<Edge>> g(v);
    g[0].push_back(Edge(1,2));
    g[0].push_back(Edge(2,4));

    g[1].push_back(Edge(4,-1));
    g[1].push_back(Edge(2,-4));

    g[2].push_back(Edge(3,2));

     g[3].push_back(Edge(4,4));
     bellmanFord(0,g,v);
          

}