#include<bits/stdc++.h>
using namespace std;

// 🌟 EXTRA: কস্ট অনেক বেশি নেগেটিভ বা পজিটিভ হতে পারে, তাই ওভারফ্লো এড়াতে long long ব্যবহার করা ভালো
// তবে তোমার বেসিক স্ট্রাকচার ঠিক রাখতে int-ই রাখা হলো, শুধু ইনফিনিটি ভ্যালু বড় করা হয়েছে।
const int INF = 1e9; 

vector<vector<int>> cost;

class Edge{
    public:
     int v;
     int w;
     Edge(int v,int w){
        this->v=v;
        this->w=w;
     }
};

// 🌟 EXTRA: abyss_detected ফ্ল্যাগটি রেফারেন্স হিসেবে পাস করা হয়েছে যেন সাইকেল পেলে মেইন ফাংশনকে জানানো যায়
void bellmanFord(int src,vector<vector<Edge>> g,int v,vector<int> emg, bool &abyss_detected){
    vector<int> dist(v,INF); // 🌟 EXTRA: INT_MAX এর বদলে INF (কারণ INT_MAX এর সাথে এজ যোগ করলে ওভারফ্লো হয়)
    dist[src]=0;
    
    // v-1 বার মূল রিলাক্সেশন লুপ
    for(int i=0;i<v;i++){
        for(int u=0;u<v;u++){
           if(dist[u] == INF) continue; // আমাদের সেই গোল্ডেন লাইন
            for(Edge e:g[u]){
                if(dist[e.v]>dist[u]+e.w){
                    dist[e.v]=dist[u]+e.w;
                }
            }
        }
    }

    // 🌟 EXTRA: v-তম বার এক্সট্রা লুপ চালানো হয়েছে নেগেটিভ সাইকেল (Abyss) ডিটেক্ট করার জন্য
    for(int u=0;u<v;u++){
        if(dist[u] == INF) continue;
        for(Edge e:g[u]){
            if(dist[e.v]>dist[u]+e.w){
                abyss_detected = true; // $V-1$ বারের পরেও মান কমছে, মানে নেগেটিভ সাইকেল আছে!
                return;
            }
        }
    }

    // তোমার সেই ফিক্সড করা পুশ লজিক
    for(int j=0;j<emg.size();j++){
        cost[emg[j]].push_back(dist[emg[j]]);
    }
}

int main(){
    int n,m,k,b,e;
    cin>>n>>m>>k>>b>>e;
    
    vector<int> cap;
    vector<int> blc;
    vector<int> emg;
    
    for(int i=0;i<k;i++){
        int c;
        cin>>c;
        cap.push_back(c);
    }
    
    for(int i=0;i<b;i++){
        int bl;
        cin>>bl;
        blc.push_back(bl);
    }
    
    // 🌟 EXTRA: দ্রুত চেক করার জন্য একটি array/vector যা বলবে কোন নোডটা ব্লকড
    vector<bool> is_blocked(n + 1, false);
    for(int i=0; i<b; i++) {
        is_blocked[blc[i]] = true;
    }

    for(int i=0;i<e;i++){
        int em;
        cin>>em;
        emg.push_back(em);
    }
    
    vector<vector<Edge>> g(n+1);
    for(int i=0;i<m;i++){
        int u,v,w;
        cin>>u>>v>>w;
        // 🌟 EXTRA: প্রবলেমের শর্ত অনুযায়ী ব্লকড সিটির কোনো পোর্টাল/এজ গ্রাফে ঢুকবে না
        if(is_blocked[u] || is_blocked[v]) continue; 
        g[u].push_back(Edge(v,w));
    }
    
    cost.resize(n+1);
    
    // 🌟 EXTRA: সাইকেল ট্র্যাকিং ফ্ল্যাগ
    bool abyss_detected = false; 
    
    for(int i=0;i<k;i++){
        // 🌟 EXTRA: ক্যাপিটাল নোডটি যদি নিজে ব্লকড না থাকে তবেই বেলম্যান-ফোর্ড চলবে
        if(!is_blocked[cap[i]]) {
            bellmanFord(cap[i],g,n+1,emg, abyss_detected);
            
            // 🌟 EXTRA: যদি Abyss ডিটেক্ট হয়, তবে সাথে সাথে প্রিন্ট করে প্রোগ্রাম বন্ধ
            if(abyss_detected) {
                cout << "Abyss Detected" << endl;
                return 0;
            }
        }
    }
    
    // এমার্জেন্সি পোস্টগুলোর মিনিমাম কস্ট বের করে প্রিন্ট করা
    for(int j=0;j<emg.size();j++){
        int min_val=INF; // 🌟 EXTRA: INT_MAX এর বদলে INF
        
        // তোমার কোডের সেই j++ টাইপো ফিক্স করে i++ করা হয়েছে
        for(int i=0;i<cost[emg[j]].size();i++){
            if(cost[emg[j]][i]<min_val)
                min_val=cost[emg[j]][i];
        }
        
        // 🌟 EXTRA: যদি কস্ট ইনফিনিটিই থেকে যায়, তার মানে আনরিচেবল (INF প্রিন্ট)
        if(min_val >= INF) {
            cout << "INF" << endl;
        } else {
            cout << min_val << endl;
        }
    }
}