#include<bits/stdc++.h>
using namespace std;
class Edge{
    public:
     int v;
     long long w;
     Edge(int v,long long w){
        this->v=v;
        this->w=w;

     }
};
void bellmanFord(int src,vector<vector<Edge>> g,int v){
    vector<long long> dist(v,LLONG_MIN);
    dist[src]=0;
    for(int i=1;i<v;i++){
        for(int u=1;u<v;u++){//v-1 iterations because highest possible number of edge to reach ith node is always i-1
            if(dist[u] == LLONG_MIN) continue;
            for(Edge e:g[u]){
                if(dist[e.v]<dist[u]+e.w){
                    dist[e.v]=dist[u]+e.w;
                }
            }
        }
    }
    if(dist[v-1]==LLONG_MIN){
        cout<<-1<<endl;
        return;
    }
    
    cout<<dist[v-1]<<endl;
}
int main(){
    
          int n,m;
          cin>>n>>m;
          vector<vector<Edge>> g(n+1);
          for(int i=0;i<m;i++){
            int a,b;
            long long c;
            cin>>a>>b>>c;
            g[a].push_back(Edge(b,c));
          }
          bellmanFord(1,g,n+1);

}