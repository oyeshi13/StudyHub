//doesnt work for neg wt
//greedy method
//for pos its more preferable than Bellman Ford
 #include<bits\stdc++.h>
using namespace std;
//cant use for neg weighted edges
class Edge{
    public: 
    int v;
    int w;
    Edge(int v,int w){
        this->v=v;
        this->w=w;
}
};
void dijkstra(int src,vector<vector<Edge>> g,int v){
    vector<int> dist(v,INT_MAX);
    dist[src]=0;
   // priority_queue<int> pq; priotorised on maximum values
   //  priority_queue<int,vector<int>,greater<int>> pq; reversed priority queue,min values come first
    priority_queue<pair<int,int>,vector<pair<int,int>>,greater<pair<int,int>>> pq;//each operation in pq is O(log(v))
    pq.push({0,src});
    while(pq.size()>0){
        int d = pq.top().first;
        int u=pq.top().second;
        pq.pop();
        if (d > dist[u]) continue;
    for(Edge e:g[u]){//edge relaxaion
        if(dist[e.v]>dist[u]+e.w){
            dist[e.v]=dist[u]+e.w;      //O((E+V)log(V)),Emax(directed)=v(v-1),Emax(idirected)=v(v-1)/2,E can be replaced with v^2.so vlogv can be ingored,and it is O(ElogV) 
            //also can be written as O(ElogE)
            pq.push({dist[e.v],e.v});
        }
   
    }
    

 }
for(int i=0;i<v;i++){
        cout<<dist[i]<<" ";
    }
    cout<<endl;

}
int main(){
    int v=6;
    vector<vector<Edge>> g(v);
    g[0].push_back(Edge(1,2));
    g[0].push_back(Edge(2,4));
    g[1].push_back(Edge(2,1));
    g[1].push_back(Edge(3,7));
    g[2].push_back(Edge(4,3));
    g[3].push_back(Edge(5,1));
    g[4].push_back(Edge(3,2));
    g[4].push_back(Edge(5,5));
    dijkstra(0,g,v);
}

