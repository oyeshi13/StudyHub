#include<bits/stdc++.h>
using namespace std;

class Edge {
public: 
    long long v;
    double w; // প্রবাবিলিটি দশমিক হওয়ায় double করা হলো
    Edge(long long v, double w) {
        this->v = v;
        this->w = w;
    }
};

void dijkstra(long long src, const vector<vector<Edge>> &g, long long v, long long des) {
    // প্রবাবিলিটি ট্র্যাকিংয়ের জন্য double ভেক্টর, শুরুতে সবার সর্বনিম্ন মান ০.০
    vector<double> dist(v, 0.0);
    dist[src] = 1.0; // সোর্স নোডের প্রবাবিলিটি সবসময় ১.০ (১০০%)

    // Max-Priority Queue: C++ এ এটা স্বয়ংক্রিয়ভাবে বড় মানকে আগে রাখে
    priority_queue<pair<double, long long>> pq;
    pq.push({1.0, src});

    while (pq.size() > 0) {
        double d = pq.top().first;
        long long u = pq.top().second;
        pq.pop();

        // যদি কিউ থেকে পাওয়া প্রবাবিলিটি ডায়েরির বেস্ট মানের চেয়ে কম হয়, তবে স্কিপ
        if (d < dist[u]) continue;
        if (u == des) break; 

        for (Edge e : g[u]) { // Edge relaxation
            // যদি নতুন গুণফল আগের জানা প্রবাবিলিটির চেয়ে বড় হয় (যেহেতু আমরা Max খুঁজছি)
            if (dist[e.v] < dist[u] * e.w) {
                dist[e.v] = dist[u] * e.w; // প্রবাবিলিটি গুণ করা হলো
                pq.push({dist[e.v], e.v});
            }
        }
    }
    // দশমিকের ৫ ঘর পর্যন্ত নিখুঁত আউটপুটের জন্য fixed এবং setprecision
    cout << fixed << setprecision(5) << dist[des] << endl;
}

int main() {
    

    int n;
    if (!(cin >> n)) return 0;
    
    vector<vector<Edge>> g(n);
    int m;
    cin >> m;
    
    vector<pair<long long, long long>> edges;
    for (int i = 0; i < m; i++) {
        long long u, v;
        cin >> u >> v;
        edges.push_back({u, v});
    }
    
    for (int i = 0; i < m; i++) {
        double s; // ইনপুট ও ডাবল (double) হিসেবে নিতে হবে
        cin >> s;
        // আনডিরেক্টেড গ্রাফ হওয়ায় দুদিকেই পুশ করা হলো
        g[edges[i].first].push_back(Edge(edges[i].second, s));
        g[edges[i].second].push_back(Edge(edges[i].first, s));
    }
    
    long long start, end_node;
    cin >> start >> end_node;
    
    dijkstra(start, g, n, end_node);
    return 0;
}