#include<bits\stdc++.h>
using namespace std;
class Edge{
    public: 
    long long v;
    long long w;
    Edge(long long v,long long w){
        this->v=v;
        this->w=w;
}

};
void dijkstra(long long src,vector<vector<Edge>> g,long long v){
    vector<long long> dist(v,LLONG_MAX);
    dist[src]=0;
   // priority_queue<int> pq; priotorised on maximum values
   //  priority_queue<int,vector<int>,greater<int>> pq; reversed priority queue,min values come first
    priority_queue<pair<long long,long long>,vector<pair<long long,long long>>,greater<pair<long long,long long>>> pq;
    pq.push({0,src});
    while(pq.size()>0){
        long long d = pq.top().first;
        long long u=pq.top().second;
        pq.pop();
        if (d > dist[u]) continue;
    for(Edge e:g[u]){//edge relaxaion
        if(dist[e.v]>dist[u]+e.w){
            dist[e.v]=dist[u]+e.w;
            pq.push({dist[e.v],e.v});
        }
   
    }
    

 }
 long long max=0;
for(int i=1;i<v;i++){
    if(dist[i]==LLONG_MAX){
        cout<<-1<<endl;//a node is unreachable
        return;
    }
       if(dist[i]>max)
       max=dist[i];
    }
    cout<<max<<endl;

}
int main(){
    long long n;
    cout<<"enter number of nodes"<<endl;
    cin>>n;
    vector<vector<Edge>> g(n+1);
    for(int i=0;i<n-1;i++){
        long long u,v,w;
        cin>>u>>v>>w;
        g[u].push_back(Edge(v,w));
    }
    long long k;
    cin>>k;
    
    dijkstra(k,g,n+1);
}
