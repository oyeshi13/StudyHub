#include<bits/stdc++.h>
using namespace std;


struct Flight {
    string id;
    string from;
    string to;
    int depMin;
    int arrMin;
};


int timeToMin(const string& t) {
    int h = stoi(t.substr(0, 2));
    int m = stoi(t.substr(3, 2));
    return h * 60 + m;
}

class Edge{
    public:
    int cap,flow,rev,to;
    Edge(int cap,int to,int flow,int rev){
        this->cap=cap;
        this->to=to;
        this->flow=flow;
        this->rev=rev;
    }
};

class graph{
   public:
    int v;
    vector<vector<Edge>> adj;
    graph(int v){
        this->v=v;
        adj.resize(v);
    }

    void addEdge(int u,int v,int cap){
        Edge forward(cap,v,0,int(adj[v].size()));
        Edge backward(0,u,0,int(adj[u].size()));
        adj[u].push_back(forward);
        adj[v].push_back(backward);
    }

    bool bfs(int source,int sink,vector<int> &parent, vector<int> &pedge){
        for(int i=0;i<v;i++){
            parent[i]=-1;
            pedge[i]=-1;
        }
        queue<int> q;
        q.push(source);
        while(!q.empty()){
            int u=q.front();
            q.pop();
            if(u==sink)
                return true;
            for(int i=0;i<adj[u].size();i++){
                Edge e=adj[u][i];
                int rcap=e.cap-e.flow;
                if(parent[e.to]==-1&&e.to!=source&&rcap>0){
                    parent[e.to]=u;
                    pedge[e.to]=i;
                    q.push(e.to);
                }
            }
        }
        return false;
    }

    int maxFlow(int source,int sink){
        int INF=1e9;
        int maxFlow=0;
        vector<int> parent(v);
        vector<int> pedge(v);
        while (bfs(source, sink, parent, pedge)) {
            int pathFlow = INF;

            for (int v = sink; v != source; v = parent[v]) {
                int u = parent[v];
                int edgeIdx = pedge[v];
                pathFlow = min(pathFlow, adj[u][edgeIdx].cap - adj[u][edgeIdx].flow);
            }

            for (int v = sink; v != source; v = parent[v]) {
                int u = parent[v];
                int edgeIdx = pedge[v];

                adj[u][edgeIdx].flow += pathFlow;

                int revIdx = adj[u][edgeIdx].rev;
                adj[v][revIdx].flow -= pathFlow;
            }

            maxFlow += pathFlow;
        }
        return maxFlow;
    }

  
    vector<int> getMatching(int F) {
        vector<int> nextFlight(F, -1);
        for (int i = 0; i < F; i++) {
            int u_out = 1 + i;
            for (Edge e : adj[u_out]) {
   
                if (e.flow == 1 && e.to >= 1 + F && e.to < 1 + 2 * F) {
                    int v_in = e.to - (1 + F);
                    nextFlight[i] = v_in;
                    break;
                }
            }
        }
        return nextFlight;
    }
};

int main() {
    int F;
  cin>>F;

    vector<Flight> flights(F);

   
    for (int i = 0; i < F; i++) {
        string depT, arrT;
        cin >> flights[i].id >> flights[i].from >> flights[i].to >> depT >> arrT;
        flights[i].depMin = timeToMin(depT);
        flights[i].arrMin = timeToMin(arrT);
    }

    int source = 0;
    int sink = 2 * F + 1;
    graph g(2 * F + 2);

    
    for (int i = 0; i < F; i++) {
        g.addEdge(source, 1 + i, 1);
        g.addEdge(1 + F + i, sink, 1);
    }

     for (int i = 0; i < F; i++) {
        for (int j = 0; j < F; j++) {
            if (i == j) continue;

           
            if (flights[i].to == flights[j].from && flights[i].arrMin + 180 <= flights[j].depMin) {
                g.addEdge(1 + i, 1 + F + j, 1);
            }
        }
    }


    int maxMatching = g.maxFlow(source, sink);
    int minAircraft = F - maxMatching;

    cout << "Number of Aircraft: " << minAircraft << "\n";


    vector<int> nextFlight = g.getMatching(F);

    vector<bool> hasIncoming(F, false);
    for (int i = 0; i < F; i++) {
        if (nextFlight[i] != -1) {
            hasIncoming[nextFlight[i]] = true;
        }
    }

    int aircraftNo = 1;
    for (int i = 0; i < F; i++) {
        if (!hasIncoming[i]) {
            cout << "Aircraft " << aircraftNo++ << ": " << flights[i].id;
            int curr = i;
            while (nextFlight[curr] != -1) {
                curr = nextFlight[curr];
                cout << " -> " << flights[curr].id;
            }
            cout << "\n";
        }
    }

    return 0;
}