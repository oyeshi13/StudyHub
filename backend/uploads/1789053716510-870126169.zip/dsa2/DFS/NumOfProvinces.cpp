//if a city is connected with b city,and b city is connected with c city,then a and c city is indirectly connected.Direct and indirect connections create provinces.
//n*n matrix is given with elements 1 & 0 only for n cities.
#include<bits/stdc++.h>
using namespace std;
void dfs(int i,vector<vector<int>> adj,vector<bool> visited){
        visited[i]=true;
        for(int j=0;j<adj[i].size();i++){
            if(adj[i][j]==1&&!visited[j]){
                dfs(j,adj,visited);
            }
        }
}
int main(){
    int NumP=0;
    int n;
    cin>>n;
    vector<vector<int>> m;
    for (int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            cin>>m[i][j];
        }
    }
    vector<bool> visited(n,false);
    vector<vector<int>> adj(n);
    for(int i=0;i<n;i++){
        if(!visited[i]){
            NumP++;
            dfs(i,m,visited);
        }

    }
}

