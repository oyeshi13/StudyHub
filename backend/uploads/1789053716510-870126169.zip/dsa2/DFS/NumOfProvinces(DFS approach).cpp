//if a city is connected with b city,and b city is connected with c city,then a and c city is indirectly connected.Direct and indirect connections create provinces.
//n*n matrix is given with elements 1 & 0 only for n cities.
#include<bits/stdc++.h>
using namespace std;
int main(){
    int n;
    cin>>n;
    int mat[n][n];
    for (int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            cin>>mat[i][j];
        }
    }
}

