#include<bits/stdc++.h>
using namespace std;
class unionSet{
   public:
    vector<int> par;
    vector<int> rank;
    vector<vector<int>> adj;
    unionSet(vector<vector<int>> adj){
        this->adj=adj;
        int n=adj.size();
        par.resize(n);
        rank.resize(n);
        for(int i=0;i<n;i++){
            par[i]=i;
            rank[i]=0;
        }
    }
    int find(int x){
        if(par[x]==x)
        return x;
        return find(par[x]);
    }
    void UnionByRank(int a,int b){
        int parA=find(a);
        int parB=find(b);
        if(parA==parB)
        return;
        if(rank[parA]==rank[parB]){
            par[parB]=parA;
            rank[parA]++;

        }
        else if(rank[parA]>rank[parB]){
           par[parB]=parA;
         

        }
        else
        {
            par[parA]=parB;
           

        }
    }
};
int main(){
    int n;
    cout<<"Enter num of cities:"<<endl;
    cin>>n;
    vector<vector<int>> adj(n,vector<int>(n));
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            cin>> adj[i][j];
        }
    }
    unionSet u(adj);
 
    int numP=0;
    for(int i=0;i<n;i++){
        for(int j=i+1;j<n;j++){
            if(adj[i][j]==1)
            u.UnionByRank(i,j);
        }

    }
    for(int i=0;i<n;i++){
        if(u.find(i)==i){
            numP++;
        }
    }
 cout<<numP<<endl;
}