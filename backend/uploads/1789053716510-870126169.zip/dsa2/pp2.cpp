#include<bits/stdc++.h>
using namespace std;
class Edge{
   public:
    int u,v,w;
    Edge(int u,int v,int w){
        this->u=u;
        this->v=v;
        this->w=w;
    }
    //comparator=> <
    bool operator<(const Edge &other)const{
        return this->w < other.w;
    }
};
class Graph{
    public:
    int V;
    int Num;
    vector<int> size;
    vector<Edge> edges;
    vector<int> par,rank;
    int maxSize;
    Graph(int V){
        this->V=V;
        Num=V-1;
        for(int i=0;i<V;i++){
            par.push_back(i);
            rank.push_back(0);
            size.push_back(1);
            maxSize=1;
        }
    }
    void addEdge(int u,int v,int w){
        edges.push_back(Edge(u,v,w));
    }
    int find(int x){
        if(par[x]==x)
        return x;
        return find(par[x]);
        
    }
    void unionByRank(int a,int b){
        int parA=find(a);
        int parB=find(b);
        if(parA==parB){
           
        return;
        }
         Num--;
        if(rank[parA]==rank[parB]){
            par[parB]=parA;
            rank[parA]++;
            size[parA]+=size[parB];
            maxSize=max(size[parA],maxSize);
        }
             else if(rank[parA]>rank[parB]){
                 par[parB]=parA;
                 size[parA]+=size[parB];
                 maxSize=max(size[parA],maxSize);
                }
    
                  else 
                    {
                        par[parA]=parB;
                        size[parB]+=size[parA];
                        maxSize=max(size[parB],maxSize);
                    }
    }
    void Kruskal(){//O(ElogE)
        sort(edges.begin(),edges.end());//O(ElogE)
        int mstCost=0;
        int edgesUsed=0;
        for(int i=0;i<edges.size();i++){//O(E)
            Edge e=edges[i];
            int parU=find(e.u);//O(1)
            int parV=find(e.v);
            if(parU!=parV){
                //No cycle;
                unionByRank(e.u,e.v);//O(1)
                edgesUsed++;
                mstCost+=e.w;
            }
        }
          if(edgesUsed!=V-1)
        {
            cout<<"impossible"<<endl;
            return;
        }
        cout<<"MST Cost: "<<mstCost<<endl;
    }
   

};
int main(){
    int m,n;
    cin>>n>>m;
    Graph g(m+1);
    for(int i=0;i<m;i++){
        int u,v;
        cin>>u>>v;
        int w=0;
        g.addEdge(u,v,w);
        g.unionByRank(u,v);
        cout<<"res:"<<g.Num<<" "<<g.maxSize<<endl;
   
     //   g.roadCons();
    }

}