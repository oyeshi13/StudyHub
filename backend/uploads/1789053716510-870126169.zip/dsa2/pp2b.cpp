#include<bits/stdc++.h>
using namespace std;
int main(){
    int m,n;
    cout<<"Number of courses:"<<endl;
    cin>>m;
    cout<<"number of req: "<<endl;
    cin>>n;
    vector<pair<int,int>> set(n);
    for(int i=0;i<n;i++){
        cin>>set[i].first;
        cin>>set[i].second;
    }
    queue<int> q;
for(int i=0;i<n;i++){
    int a=set[i].first;
    for(int j=0;j<n;j++){
        if(set[j].second==a)
    }
}
}