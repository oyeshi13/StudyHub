//doesnt work for neg cycle
#include<bits/stdc++.h>
using namespace std;
class graph{
    public: vector<vector<pair<int,int>>> adj;
            int V;
            graph(int V){
                this->V=V;
                adj.resize(V);
            }

            void addEdge(int u,int v,int w){
                adj[u].push_back({v,w});
            }

            void floydWarshal(){
                const int INF=1e9;
                vector<vector<int>> dist(V,vector<int>(V,INF));
                for(int i=0;i<V;i++){
                    dist[i][i]=0;
                }
                for(int u=0;u<V;u++){
                    for(auto edge:adj[u]){
                        int v=edge.first;
                        int w=edge.second;
                        dist[u][v]=w;
                    }
                }
                
                //core logic

                for(int k=0;k<V;k++){
                    for(int i=0;i<V;i++){
                        for(int j=0;j<V;j++){
                            if(dist[i][k] != INF && dist[k][j] != INF)
                            dist[i][j]=min(dist[i][j],dist[i][k]+dist[k][j]);
                        }
                    }
                }

                //check neg weight
                for(int i=0;i<V;i++){
                    if(dist[i][i]<0){
                        cout<<"neg weight cycle exists"<<endl;
                        return;
                    }
                }
                for(int i=0;i<V;i++){
                    for(int j=0;j<V;j++){
                        if(dist[i][j]==INF){
                            cout<<"INF ";

                        }
                        else 
                        cout<<dist[i][j]<<" ";
                    }
                    cout<<endl;
                }

                
            }
};
int main(){
    graph g(4);
    g.addEdge(0,1,4);
    g.addEdge(0,2,11);
    g.addEdge(1,2,2);
    g.addEdge(3,1,-8);
    g.addEdge(2,3,3);
    g.floydWarshal();

}