#include<bits/stdc++.h>
using namespace std;
class graph{
    public: vector<vector<pair<int,long long>>> adj;
            int V;
            graph(int V){
                this->V=V;
                adj.resize(V);
            }

            void addEdge(int u,int v,long long w){
                adj[u].push_back({v,w});
            }

            vector<vector<long long>> floydWarshal(){
                const long long INF=1e9;
                vector<vector<long long>> dist(V,vector<long long>(V,INF));
                for(int i=0;i<V;i++){
                    dist[i][i]=0;
                }
                for(int u=0;u<V;u++){
                    for(auto edge:adj[u]){
                        int v=edge.first;
                        long long w=edge.second;
                        dist[u][v]=w;
                    }
                }
                
                //core logic

                for(int k=0;k<V;k++){
                    for(int i=0;i<V;i++){
                        for(int j=0;j<V;j++){
                            if(dist[i][k] != INF && dist[k][j] != INF)
                            dist[i][j]=min(dist[i][j],dist[i][k]+dist[k][j]);
                        }
                    }
                }

                //check neg weight
               /* for(int i=0;i<V;i++){
                    if(dist[i][i]<0){
                        cout<<"neg weight cycle exists"<<endl;
                        return;
                    }
                }*/
              /*for(int i=0;i<V;i++){
                    for(int j=0;j<V;j++){
                        if(dist[i][j]==INF){
                            cout<<"INF ";

                        }
                        else 
                        cout<<dist[i][j]<<" ";
                    }
                    cout<<endl;
                }*/
                return dist;
                
            }
};
int main(){
    int n,m;
    cin>>n>>m;
    graph g(n+1);
    for(int i=0;i<m;i++){
        int u,v;
        long long w;
        cin>>u>>v>>w;
        g.addEdge(u,v,w);
    }
    int y,z;
    cin>>y>>z;
    int q;
    cin>>q;
    const int INF=1e9;
    
    vector<vector<long long>> dist=g.floydWarshal();
    while(q!=0){
        int a,b;
        cin>>a>>b;
        q--;
        long long ans1=INF;
        long long ans2=INF;
        int st=0;
        if(dist[a][y]!=INF && dist[y][b]!=INF){
            ans1=min(ans1,dist[a][y]+dist[y][b]);
           // st=y;
        }
        if(dist[a][z]!=INF && dist[z][b]!=INF){
            ans2=min(ans2,dist[a][z]+dist[z][b]);
            st=z;
        }
        if(ans1==INF&&ans2==INF){
            cout<<-1<<endl;
        }
      else   {
        int ans=min(ans1,ans2);
        if(ans1==ans2){
            cout<<ans1<<" ";
            cout<<min(y,z)<<endl;
        }
        else if(ans==ans1){
            cout<<ans1<<" ";
            cout<<y<<endl;
        }
       else if(ans==ans2){
            cout<<ans2<<" ";
            cout<<z<<endl;
        }
      }
    }

}