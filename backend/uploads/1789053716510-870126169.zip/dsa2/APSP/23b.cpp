#include<bits/stdc++.h>
using namespace std;
class graph{
    public: vector<vector<pair<int,int>>> adj;
            int V;
            graph(int V){
                this->V=V;
                adj.resize(V);
            }

            void addEdge(int u,int v,int w){
                adj[u].push_back({v,w});
            }

            vector<vector<int>> floydWarshal(){
                const int INF=1e9;
                vector<vector<int>> dist(V,vector<int>(V,INF));
                for(int i=0;i<V;i++){
                    dist[i][i]=0;
                }
                for(int u=0;u<V;u++){
                    for(auto edge:adj[u]){
                        int v=edge.first;
                        int w=edge.second;
                        dist[u][v]=w;
                    }
                }
                
                //core logic

                for(int k=0;k<V;k++){
                    for(int i=0;i<V;i++){
                        for(int j=0;j<V;j++){
                            if(dist[i][k] != INF && dist[k][j] != INF)
                            dist[i][j]=min(dist[i][j],dist[i][k]+dist[k][j]);
                        }
                    }
                }

                //check neg weight
               /* for(int i=0;i<V;i++){
                    if(dist[i][i]<0){
                        cout<<"neg weight cycle exists"<<endl;
                        return;
                    }
                }*/
              /*for(int i=0;i<V;i++){
                    for(int j=0;j<V;j++){
                        if(dist[i][j]==INF){
                            cout<<"INF ";

                        }
                        else 
                        cout<<dist[i][j]<<" ";
                    }
                    cout<<endl;
                }*/
                return dist;
                
            }
};
int main(){
    int n,m;
    cin>>n>>m;
    graph g(n);
    for(int i=0;i<m;i++){
        int u,v,w;
        cin>>u>>v>>w;
        g.addEdge(u,v,w);
    }
    int y,z;
    cin>>y>>z;
    int q;
    cin>>q;
    const int INF=1e9;
    
    vector<vector<int>> dist=g.floydWarshal();
    while(q!=0){
        int a,b;
        cin>>a>>b;
        q--;
        int ans=INF;
        if(dist[a][y]!=INF && dist[y][b]!=INF){
            ans=min(ans,dist[a][y]+dist[y][b]);
        }
        if(dist[a][z]!=INF && dist[z][b]!=INF){
            ans=min(ans,dist[a][z]+dist[z][b]);
        }
        if(ans==INF){
            cout<<-1<<endl;
        }
        else
        cout<<ans<<endl;
    }

}