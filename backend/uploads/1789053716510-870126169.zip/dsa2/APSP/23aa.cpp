#include<bits/stdc++.h>
using namespace std;

class graph {
public: 
    vector<vector<pair<int, double>>> adj;
    int V;

    graph(int V) {
        this->V = V;
        adj.resize(V);
    }

    void addEdge(int u, int v, double w) {
        adj[u].push_back({v, w});
    }

    vector<vector<double>> floydWarshal() {
        const double INF = 1e15;
        vector<vector<double>> dist(V, vector<double>(V, INF));
        for(int i = 0; i < V; i++) {
            dist[i][i] = 0.0;
        }
        for(int u = 0; u < V; u++) {
            for(auto edge : adj[u]) {
                int v = edge.first;
                double w = edge.second;
                dist[u][v] = min(dist[u][v], w); 
            }
        }
        
        // core logic
        for(int k = 0; k < V; k++) {
            for(int i = 0; i < V; i++) {
                for(int j = 0; j < V; j++) {
                    if(dist[i][k] != INF && dist[k][j] != INF)
                        dist[i][j] = min(dist[i][j], dist[i][k] + dist[k][j]);
                }
            }
        }
        return dist; 
    }
};

int getCurId(string src, vector<string> cur, int n) {
    for(int i = 0; i < n; i++) {
        if (src == cur[i])
            return i;
    }
    return -1;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int n, m;
    while(cin >> n) {
        vector<string> curr(n);
        for(int i = 0; i < n; i++) {
            cin >> curr[i];
        }
        
        cin >> m;
        graph g(n);
        
        for(int i = 0; i < m; i++) {
            string src, dest;
            double w;
            cin >> src >> w >> dest;
            int u = getCurId(src, curr, n);
            int v = getCurId(dest, curr, n);
            double weight = -log(w);

            g.addEdge(u, v, weight);
        }
        
        vector<vector<double>> dist = g.floydWarshal();
        vector<string> arb;
        
        for(int i = 0; i < n; i++) {
            if(dist[i][i] < -1e-9) {
                arb.push_back(curr[i]);
            }
        }
        
        if(arb.empty()) {
            cout << "No Arbitrage" << endl;
        }
        else {
            for(int i = 0; i < arb.size(); i++) {
                cout << arb[i] << endl;
            }
        }
    }
    return 0;
}