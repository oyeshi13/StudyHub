#include<iostream>
#include<bits/stdc++.h>
using namespace std;
bool primeCheck(int n){
    if(n<=1) return false;
    if(n==2) return true;
    int c=0;
    for(int i=2;i*i<=n;i++){
        if (n%i==0)
        {c++;
        break;
        }
    }
    if(c==0) return true;
    return false;
}
int getNextPrime(int n){
    while(!primeCheck(n)){
        n++;
    }
    return n;
}

int Hash1(string str,int n){
    long long val=0;
    for(int i=0;i<str.length();i++){
        val=(val*31+str[i])%n;
    }
    return val;
}
int Hash2(string str,int n){
    long long val=5381;
    for(int i=0;i<str.length();i++){
        val=((val<<5)+val+str[i])%n;
        
    }
    return val;
}
int auxHash(string str,int n){
    long long val = 0;
    for (int i = 0; i < str.length(); i++) {
        val = (val * 37 + str[i]);
    }
    int h = val % n;
    return h == 0 ? 1 : h;
}
class Node{
    public:
     string key;
     int val;
     Node* next;

};
class chainHash{
    public:
    vector<Node*> table;
    int size,elements,insertions,collisions;
    bool useHash1;
    chainHash(int size,bool useHash1){
        this->size=size;
        elements=0;
        insertions=0;
        collisions=0;
        this->useHash1=useHash1;
        table.assign(size,NULL);
    }
    void resize(int new_size) {
        vector<Node*> old_table = table; 
        int old_size =size; 
        
        size = new_size;
        table.assign(size, NULL); 
        
        elements = 0; 
        insertions = 0;
        collisions = 0;
        
        for (int i = 0; i < old_size; i++) {
            Node* curr = old_table[i];
            while (curr != NULL) { 
                insert(curr->key, curr->val); 
                Node* temp = curr; 
                curr = curr->next; 
                delete temp; 
            }
        }
    }
    void insert(string key,int val){
        if(float(elements)/size>0.5 && insertions>=elements/2)
        {int new_size=getNextPrime(size*2+1);
        resize(new_size);
    }
        int idx;
        if(useHash1){
            idx=Hash1(key,size);

        }
        else
               idx=Hash2(key,size);

        Node* curr=table[idx];
        while(curr!=NULL){
            if(curr->key==key)
            return;
            curr=curr->next;

        }
        if(table[idx]!=NULL)
        collisions++;

        Node* newNode=new Node();
        newNode->key=key;
        newNode->val=val;
        newNode->next=table[idx];
        table[idx]=newNode;
        elements++;
        insertions++;
    }

    int search(string key,int& hits){
        int idx;
        if (useHash1) {
            idx = Hash1(key,size);
        } else {
            idx = Hash2(key,size);
        }

        Node* curr = table[idx];
        while (curr != NULL) { 
            hits++; 
            if (curr->key == key) {
                return curr->val; 
            }
            curr = curr->next; 
        }
        return -1;
    }
};
class HashNode{
    public:
    string key;
    int val;
    bool isOccupied;
    bool isDeleted;
    HashNode(){
        isOccupied = false;
        isDeleted = false;
    }

};
class openHash {
public:
    vector<HashNode> table;
    int size;
    int elements;
    int insertions;
    int collisions;
    int probingType; 
    int C1;
    int C2;
    bool useHash1;

    openHash(int size, bool useHash1, int probingType) {
        this->size = size;
        this->useHash1 = useHash1;
        this->probingType = probingType;
        elements = 0;
        insertions = 0;
        collisions = 0;
        C1 = 3;
        C2 = 5;
        table.resize(size);
    }
    void insert(string key, int val) {
        if ((float)elements / size > 0.5 && insertions >= elements / 2) {
            int new_size = getNextPrime(size * 2 + 1);
            resize(new_size);
        }

        int hash_val;
        if (useHash1) {
            hash_val = Hash1(key, size);
        } else {
            hash_val = Hash2(key, size);
        }

        int aux_val = auxHash(key, size);
        int i = 0;
        int idx = hash_val;

        while (table[idx].isOccupied && !table[idx].isDeleted) {
            if (table[idx].key == key) {
                return;
            }

            collisions++;
            i++;

            if (probingType == 1) {
                idx = (hash_val + i * aux_val) % size;
            } else {
                idx = (hash_val + C1 * i * aux_val + C2 * i * i) % size;
            }
        }

        table[idx].key = key;
        table[idx].val = val;
        table[idx].isOccupied = true;
        table[idx].isDeleted = false;

        elements++;
        insertions++;
    }
void resize(int new_size) {
        vector<HashNode> old_table = table;
        int old_size = size;

        size = new_size;
        table.clear();
        table.resize(size);

        elements = 0;
        insertions = 0;
        collisions = 0;
        for (int j = 0; j < old_size; j++) {
            if (old_table[j].isOccupied && !old_table[j].isDeleted) {
                insert(old_table[j].key, old_table[j].val);
            }
        }
    }
int search(string key, int& hits) {
        int hash_val;
        if (useHash1) {
            hash_val = Hash1(key, size);
        } else {
            hash_val = Hash2(key, size);
        }

        int aux_val = auxHash(key, size);
        int i = 0;
        int idx = hash_val;

        while (table[idx].isOccupied) {
            hits++;
            if (!table[idx].isDeleted && table[idx].key == key) {
                return table[idx].val;
            }

            i++;

            if (probingType == 1) {
                idx = (hash_val + i * aux_val) % size;
            } else {
                idx = (hash_val + C1 * i * aux_val + C2 * i * i) % size;
            }

            if (i > size) {
                break;
            }
        }
        return -1;
    }
    void printProbeSequence(string key) {
    int hash_val;
    if (useHash1 == true) {
        hash_val = Hash1(key, size);
    } else {
        hash_val = Hash2(key, size);
    }
    
    int aux_val = auxHash(key, size);
    int i = 0;
    int idx = hash_val;
    
    // Shurutei primary index print kora
    cout << idx;
    
    // Ghor vora thakle shamne agabe
    while (table[idx].isOccupied == true) {
        // Ashol word-ti mile gele thamte hobe
        if (table[idx].key == key && table[idx].isDeleted == false) {
            break; 
        }
        
        i++;
        if (i > size) {
            break; // Infinite loop thekano
        }
        
        // Formula onujayi porer index ber kora
        if (probingType == 1) {
            idx = (hash_val + i * aux_val) % size;
        } else if (probingType == 2) {
            idx = (hash_val + C1 * i * aux_val + C2 * i * i) % size;
        }
        
        // Tir chinho diye sequence print kora
        cout << " -> " << idx;
    }
    cout << endl;
}
};

string generateRandomWord(int length) {
    string word = "";
    for (int i = 0; i < length; i++) {
        word += (char)('a' + rand() % 26);
    }
    return word;
}
int main() {

   openHash dh1(13, true, 1); 

    // 10,000 unique word insert kora
    for (int i = 0; i < 10000; i++) {
        string w = generateRandomWord(10);
        if (i == 5) cout << "Test Word: " << w << endl;
        dh1.insert(w, i + 1);
    }

    // Nirdeshona onujayi input neya
    int n;
    cin >> n;
    
    for (int i = 0; i < n; i++) {
        string k;
        cin >> k;
        // Search ba probe sequence print kora
        dh1.printProbeSequence(k);
    }

    return 0;
}