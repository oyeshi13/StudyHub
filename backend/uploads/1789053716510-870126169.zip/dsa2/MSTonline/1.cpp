#include<bits/stdc++.h>
using namespace std;
class Edge{
   public:
    int u,v,w;
    Edge(int u,int v,int w){
        this->u=u;
        this->v=v;
        this->w=w;
    }
    //comparator=> <
    bool operator<(const Edge &other){
        return this->w < other.w;
    }
};
class Graph{
    public:
    int V;
    vector<Edge> edges;
    vector<int> par,rank;
    Graph(int V){
        this->V=V;
        for(int i=0;i<V;i++){
            par.push_back(i);
            rank.push_back(0);
        }
    }
    void addEdge(int u,int v,int w){
        edges.push_back(Edge(u,v,w));
    }
    int find(int x){
        if(par[x]==x)
        return x;
        return par[x]=find(par[x]);
        
    }
    void unionByRank(int a,int b){
        int parA=find(a);
        int parB=find(b);
        if(parA==parB)
        return;
        if(rank[parA]==rank[parB]){
            par[parB]=parA;
            rank[parA]++;
        }
             else if(rank[parA]>rank[parB]){
                 par[parB]=parA;
                }
    
                  else 
                    {
                        par[parA]=parB;
                    }
    }
    
    void missingRoads(){
        vector<pair<int,int>> newRoad;
        int k=0;
        for(int i=2;i<V-1;i++){
            if(find(1)!=find(i)){
                unionByRank(1,i);
                k++;
                newRoad.push_back({1,i});
            }
        }
        cout<<k<<endl;
        for(int j=0;j<newRoad.size();j++){
            cout<<newRoad[j].first<<" "<<newRoad[j].second;
        }
    }

};
int main(){
    int n,m;
    cout<<"Enter number of cities"<<endl;
    cin>>n;
    cout<<"Enter number of roads"<<endl;
    cin>>m;
    Graph g(n+1);
    for(int i=0;i<m;i++){
        int u,v;
        cin>>u>>v;
        g.addEdge(u,v,0);
        g.unionByRank(u,v);

    }
    g.missingRoads();



}