#include<bits/stdc++.h>
using namespace std;
struct Planet{
    int x,y,z,id;
};
class Edge{
    public:
    int u,v,w;
    Edge(int u,int v,int w){
        this->u=u;
        this->v=v;
        this->w=w;
    }
    bool operator<(Edge const &other){
        return this->w<other.w;
    }
};
class Graph{
    public:
    int N;
    vector<Edge>edges;
    vector<int> par,rank;
    Graph(int N){
        this->N=N;
        for(int i=0;i<N;i++){
            par.push_back(i);
            rank.push_back(0);
        }
    }
    void addEdge(int u,int v,int w){
        edges.push_back(Edge(u,v,w));
    }
    int find(int x){
        if(par[x]==x)
        return x;
        return find(par[x]);
    }
    void unionByRank(int a ,int b){
        int parA=find(a);
        int parB=find(b);
        if(parA==parB)
        return;
        if(rank[parA]==rank[parB]){
            par[parB]=parA;
            rank[parA]++;
        }
             else if(rank[parA]>rank[parB]){
                 par[parB]=parA;
                }
    
                  else 
                    {
                        par[parA]=parB;
                    }
    }
    void findMin(){
        sort(edges.begin(),edges.end());//O(ElogE)
        int mstCost=0;
        for(int i=0;i<edges.size();i++){//O(E)
            Edge e=edges[i];
            int parU=find(e.u);//O(1)
            int parV=find(e.v);
            if(parU!=parV){
                //No cycle;
                unionByRank(e.u,e.v);//O(1)
                mstCost+=e.w;
            }
        }
        cout<<"Minimum Cost: "<<mstCost<<endl;
    }
};
bool CompX(Planet a, Planet b){
    return a.x<b.x;
}
bool CompY(Planet a, Planet b){
    return a.y<b.y;
}
bool CompZ(Planet a, Planet b){
    return a.z<b.z;
}
int main(){
    int N;
    cout<<"Enter num of planets: "<<endl;
    cin>>N;
    vector<Planet> planets(N);
    for(int i=0;i<N;i++){
        int  x,y,z;
        cin>>planets[i].x;
        cin>>planets[i].y;
        cin>>planets[i].z;
        planets[i].id=i;
    }
    Graph g(N);
    sort(planets.begin(),planets.end(),CompX);
    for(int i=0;i<N-1;i++){
        int cost=abs(planets[i].x-planets[i+1].x);
        g.addEdge(planets[i].id,planets[i+1].id,cost);
    }
    sort(planets.begin(),planets.end(),CompY);
    for(int i=0;i<N-1;i++){
        int cost=abs(planets[i].y-planets[i+1].y);
        g.addEdge(planets[i].id,planets[i+1].id,cost);
    }
    sort(planets.begin(),planets.end(),CompZ);
    for(int i=0;i<N-1;i++){
        int cost=abs(planets[i].z-planets[i+1].z);
        g.addEdge(planets[i].id,planets[i+1].id,cost);
    }
    g.findMin();
}

