#include<bits/stdc++.h>
using namespace std;

class Edge{
   public:
    int u,v,w;
    Edge(int u,int v,int w){
        this->u=u;
        this->v=v;
        this->w=w;
    }
    // সোর্টিং সেফটির জন্য const যোগ করা হয়েছে
    bool operator<(const Edge &other) const {
        return this->w < other.w;
    }
};

class Graph{
    public:
    int V;
    // পরিবর্তন ১: একক edges ভেক্টরের বদলে দুটি আলাদা ভেক্টর
    vector<Edge> safe_edges;
    vector<Edge> risky_edges;
    vector<int> par,rank;
    
    Graph(int V){
        this->V=V;
        for(int i=0;i<V;i++){
            par.push_back(i);
            rank.push_back(0);
        }
    }
    
    // পরিবর্তন ২: আলাদা ভেক্টরে পুশ করার জন্য দুটি ফাংশন
    void addSafeEdge(int u,int v,int w){
        safe_edges.push_back(Edge(u,v,w));
    }
    void addRiskyEdge(int u,int v,int w){
        risky_edges.push_back(Edge(u,v,w));
    }
    
    int find(int x){
        if(par[x]==x)
            return x;
        return par[x]=find(par[x]); // Path compression
    }
    
    bool unionByRank(int a,int b){
        int parA=find(a);
        int parB=find(b);
        if(parA==parB)
            return false; // অলরেডি একই গ্রুপে থাকলে false
        
        if(rank[parA]==rank[parB]){
            par[parB]=parA;
            rank[parA]++;
        }
        else if(rank[parA]>rank[parB]){
            par[parB]=parA;
        }
        else {
            par[parA]=parB;
        }
        return true; // সফলভাবে কানেক্ট হলে true
    }
    
    // -------------------------------------------------------------------------
    // 🛠️ মডিফাইড ক্রুসকল ফাংশন (২-ফেজ লজিক এবং কানেক্টিভিটি চেক)
    // -------------------------------------------------------------------------
    void Kruskal(vector<int>& safe_cities){
        sort(safe_edges.begin(), safe_edges.end());
        sort(risky_edges.begin(), risky_edges.end());
        
        int mstCost = 0;
        vector<pair<int,int>> final_edges;
        
        // --- ফেজ ১: শুধু সেফ এজ দিয়ে কানেক্ট করার ট্রাই ---
        for(int i=0; i<safe_edges.size(); i++){
            Edge e = safe_edges[i];
            if(unionByRank(e.u, e.v)){
                mstCost += e.w;
                final_edges.push_back({e.u, e.v});
            }
        }
        
        // --- ফেজ ২: সেফ সিটিগুলো বিচ্ছিন্ন থাকলে রিস্কি এজ একটি একটি করে যোগ করা ---
        for(int i=0; i<risky_edges.size(); i++){
            // প্রতিবার এজ নেওয়ার আগে চেক করি সব সেফটি সিটি অলরেডি কানেক্টেড কি না
            bool all_safe_connected = true;
            if(!safe_cities.empty()){
                int base_leader = find(safe_cities[0]);
                for(int j=1; j<safe_cities.size(); j++){
                    if(find(safe_cities[j]) != base_leader){
                        all_safe_connected = false;
                        break;
                    }
                }
            }
            
            // যদি সব সেফ সিটি অলরেডি কানেক্ট হয়ে যায়, আর কোনো রিস্কি এজ নেব না!
            if(all_safe_connected) {
                break;
            }
            
            Edge e = risky_edges[i];
            if(unionByRank(e.u, e.v)){
                mstCost += e.w;
                final_edges.push_back({e.u, e.v});
            }
        }
        
        // ফাইনাল ভেরিফিকেশন: এখনও কি কোনো সেফ সিটি বিচ্ছিন্ন?
        if(!safe_cities.empty()){
            int final_leader = find(safe_cities[0]);
            for(int i=1; i<safe_cities.size(); i++){
                if(find(safe_cities[i]) != final_leader){
                    cout << "-1" << endl;
                    return;
                }
            }
        }
        
        // আউটপুট প্রিন্ট
        cout << final_edges.size() << endl;
        for(int i=0; i<final_edges.size(); i++){
            cout << final_edges[i].first << " " << final_edges[i].second << endl;
        }
        cout << mstCost << endl;
    }
};

int main(){
    // Fast I/O
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int N, M, P;
    if (!(cin >> N >> M >> P)) return 0;
   
    int K;
    Graph g(N);
    cin >> K;
    
    // Boolean Flag array ফর ওয়ান-শট রিস্ক চেকিং
    vector<bool> is_risky(N, false);
    for(int i=0; i<K; i++){
        int r;
        cin >> r;
        is_risky[r] = true;
    }
    
    // সেফ সিটিগুলো ট্র্যাকিং ভেক্টরে রাখা
    vector<int> safe_cities;
    for(int i=0; i<N; i++){
        if(!is_risky[i]) safe_cities.push_back(i);
    }
    
    for(int i=0; i<M; i++){
        int u, v, w;
        cin >> u >> v >> w;
        
        // লুপ ছাড়া ডিরেক্ট পেনাল্টি হিসাব
        int risky_endpoints = 0;
        if(is_risky[u]) risky_endpoints++;
        if(is_risky[v]) risky_endpoints++;
        
        int effective_w = w + (P * risky_endpoints);
        
        // সেফ নাকি রিস্কি সেই অনুযায়ী আলাদা পুশ
        if(risky_endpoints == 0){
            g.addSafeEdge(u, v, effective_w);
        } else {
            g.addRiskyEdge(u, v, effective_w);
        }
    }
    
    g.Kruskal(safe_cities);
    return 0;
}