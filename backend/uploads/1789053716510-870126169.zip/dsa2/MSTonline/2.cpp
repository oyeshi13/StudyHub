#include<bits/stdc++.h>
using namespace std;
class Edge{
   public:
    int u,v,w;
    Edge(int u,int v,int w){
        this->u=u;
        this->v=v;
        this->w=w;
    }
    //comparator=> <
    bool operator<(const Edge &other)const{
        return this->w < other.w;
    }
};
class Graph{
    public:
    int V;
    int Num;
    vector<Edge> edges;
    vector<int> par,rank,size;
    int maxSize;
    Graph(int V){
        this->V=V;
        Num=V-1;
        maxSize=1;
        for(int i=0;i<V;i++){
            par.push_back(i);
            rank.push_back(0);
            size.push_back(1);
        }
    }
    void addEdge(int u,int v,int w){
        edges.push_back(Edge(u,v,w));
    }
    int find(int x){
        if(par[x]==x)
        return x;
        return par[x]=find(par[x]);
        
    }
    void unionByRank(int a,int b){
        int parA=find(a);
        int parB=find(b);
        if(parA==parB)
        return;
        Num--;///age thekei jodi same grp er part na hoi tahole num of comp kome jabe
        if(rank[parA]==rank[parB]){
            par[parB]=parA;
            rank[parA]++;
            size[parA]+=size[parB];
            maxSize=max(maxSize,size[parA]);
        }
             else if(rank[parA]>rank[parB]){
                 par[parB]=parA;
                  size[parA]+=size[parB];
            maxSize=max(maxSize,size[parA]);
                }
    
                  else 
                    {
                        par[parA]=parB;
                         size[parB]+=size[parA];
            maxSize=max(maxSize,size[parB]);
                    }
    }
    
};
int main(){
   int n,m;
   cin>>n;
   cin>>m;
   Graph g(n+1);
   int w=0;
   for(int i=0;i<m;i++){
    int u,v;
    cin>>u>>v;
    g.addEdge(u,v,w);
    g.unionByRank(u,v);
    
    cout<<"res:"<<g.Num<<" "<<g.maxSize<<endl;
   
   }


}