#include<bits/stdc++.h>
using namespace std;
class Edge{
   public: int u,v,w;
    Edge(int u,int v,int w){
        this->u=u;
        this->v=v;
        this->w=w;
    }
    bool operator<(Edge const &other){
        return this->w<other.w;
    }
};
class graph{
  public:  int V;
    vector<Edge> edges;
    vector<int> par,rank;
    graph(int V){
        this->V=V;
      //  par.resize(V);
       // rank.resize(V);
        for(int i=0;i<V;i++){
            par.push_back(i);
            rank.push_back(0);
        }
    }
    void resetDSU(){
         for(int i=0;i<V;i++){
            par[i]=i;
            rank[i]=0;
        }
    }
    int find(int x){
        if(par[x]==x)
        return x;
        return find(par[x]);
    }
    void unionByRank(int a,int b){
        int parA=find(a);
        int parB=find(b);
        if(parA==parB)
        return;
        if(rank[parA]==rank[parB]){
            par[parB]=parA;
            rank[parA]++;
        }
        else if(rank[parA]>rank[parB]){
            par[parB]=parA;
        }
        else {
            par[parA]=parB;
        }
    }
    void addEdge(int u,int v,int w){
        edges.push_back(Edge(u,v,w));
    }
    void kruskal(){
        vector<Edge> e;
        int mstCost=0;
        sort(edges.begin(),edges.end());
        for(int i=0;i<edges.size();i++){
            int parU=find(edges[i].u);
            int parV=find(edges[i].v);
            if(parU!=parV){
                unionByRank(edges[i].u,edges[i].v);
            e.push_back(edges[i]);
            mstCost+=edges[i].w;
            }


        }
        if(e.size()!=V-1){
            cout<<"No Spanning tree possible"<<endl;
        }
 int secondCost=INT_MAX;
 for(int i=0;i<e.size();i++){
    int curCost=0;
    resetDSU();
    for(int j=0;j<edges.size();j++){
        if(edges[j].u==e[i].u&&edges[j].v==e[i].v&&edges[j].w==e[i].w)
        continue;
        int parU=find(edges[j].u);
            int parV=find(edges[j].v);
            if(parU!=parV){
                unionByRank(edges[j].u,edges[j].v);
         curCost+=edges[j].w;
    }
    

 }
 secondCost=min(secondCost,curCost);
 
    }
    cout<<secondCost<<endl;
}
};
int main(){
    graph g(4);

    g.addEdge(0, 1, 10);
    g.addEdge(0, 2, 6);
    g.addEdge(0, 3, 5);
    g.addEdge(1, 3, 15);
    g.addEdge(2, 3, 4);

    g.kruskal();
    return 0;
}