#include<bits/stdc++.h>
using namespace std;
class Edge{
   public:
    int u,v,w;
    Edge(int u,int v,int w){
        this->u=u;
        this->v=v;
        this->w=w;
    }
    //comparator=> <
    bool operator<(const Edge &other){
        return this->w < other.w;
    }
};
class Graph{
    public:
    int V;
    vector<Edge> edges;
    vector<int> par,rank;
    Graph(int V){
        this->V=V;
        for(int i=0;i<V;i++){
            par.push_back(i);
            rank.push_back(0);
        }
    }
    void addEdge(int u,int v,int w){
        edges.push_back(Edge(u,v,w));
    }
    int find(int x){
        if(par[x]==x)
        return x;
        return find(par[x]);
        
    }
    void unionByRank(int a,int b){
        int parA=find(a);
        int parB=find(b);
        if(parA==parB)
        return;
        if(rank[parA]==rank[parB]){
            par[parB]=parA;
            rank[parA]++;
        }
             else if(rank[parA]>rank[parB]){
                 par[parB]=parA;
                }
    
                  else 
                    {
                        par[parA]=parB;
                    }
    }
    void Kruskal(){//O(ElogE)
        vector<Edge> res;
        sort(edges.begin(),edges.end());//O(ElogE)
        int mstCost=0;
        int edgesUsed=0;
        for(int i=0;i<edges.size();i++){//O(E)
            Edge e=edges[i];
            int parU=find(e.u);//O(1)
            int parV=find(e.v);
            if(parU!=parV){
                //No cycle;
                unionByRank(e.u,e.v);//O(1)
                mstCost+=e.w;
                edgesUsed++;
                res.push_back(Edge(e.u,e.v,e.w));
            }
        }
        if(edgesUsed!=V-1)
        {
            cout<<"impossible"<<endl;
            return;
        }
        cout<<"MST Cost: "<<mstCost<<endl;
        for(int i=0;i<res.size();i++){
            cout<<res[i].u<<" "<<res[i].v<<" "<<res[i].w;
            cout<<endl;
        }
    }

};
int main(){
    int N,M;
    cin>>N>>M;
    Graph g(N+1);
    for(int i=0;i<M;i++){
        int u,v,w;
        cin>>u>>v>>w;
        g.addEdge(u,v,w);
    }
    g.Kruskal();

    


}