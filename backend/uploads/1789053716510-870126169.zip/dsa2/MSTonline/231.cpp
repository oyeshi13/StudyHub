#include<bits/stdc++.h>
using namespace std;
class Edge{
    public:
    int u,v,w;
    Edge(int u,int v,int w){
        this->u=u;
        this->v=v;
        this->w=w;
    }
    bool operator<(Edge const &other){
        return this->w<other.w;
    }
};
class Graph{
    public:
   
    int N;
    vector<Edge> edges;
    vector<int> par,rank;
    Graph(int N){
        this->N=N;
      
        for(int i=0;i<=N;i++){//we r assuming a virtual node o so number of nodes will be N+1
            par.push_back(i);
            rank.push_back(0);
        }
    }
    int find(int x){
        if(par[x]==x)
        return x;
        return find(par[x]);
    }
    void unionByRank(int a,int b){
        int parA=find(a);
        int parB=find(b);
        if(parA==parB)
        return;
        if(rank[parA]==rank[parB]){
            par[parB]=parA;
            rank[parA]++;
        }
        else  if(rank[parA]>rank[parB]){
            par[parB]=parA;
            
        }
        else
          par[parA]=parB;
    }
 void addEdge(int u,int v,int w){
    edges.push_back(Edge(u,v,w));
 }
 void MinCost(){
    sort(edges.begin(),edges.end());
    int min=0;
    for(int i=0;i<edges.size();i++){
        int parU=find(edges[i].u);
        int parV=find(edges[i].v);
    //    if(parU!=parV||(edges[i].u==edges[i].v)) 
    // we cant consider power station cost as self loop as its cotradicting with MST
    if(parU!=parV){
            unionByRank(edges[i].u,edges[i].v);
            min+=edges[i].w;
        }
    }
    cout<<"MIN COST: "<<min<<endl;
 }

};
int main(){
    int M, N;
    
    cout << "Number of cities: " << endl;
    cin >> N;
    
    Graph g(N); // ১ নম্বর ফিক্স অনুযায়ী অবজেক্ট তৈরি
    
    cout << "Cost of building station in each city: " << endl;
    for(int i = 1; i <= N; i++){
        int cost;
        cin >> cost;
        // ভার্চুয়াল নোড 0 থেকে সিটি i তে এজ তৈরি (পাওয়ার স্টেশন কস্ট)
        g.addEdge(0, i, cost);
    }
    
    cout << "Number of cables: " << endl;
    cin >> M;
    
    cout << "Enter cables details (u v weight) for each connection:" << endl;
    for(int i = 0; i < M; i++){
        int u, v, w;
        cin >> u >> v >> w;
        g.addEdge(u, v, w); // কেবলের এজ যোগ করা
    }
    
    g.MinCost(); // ফাইনাল কস্ট প্রিন্ট
    return 0;
}