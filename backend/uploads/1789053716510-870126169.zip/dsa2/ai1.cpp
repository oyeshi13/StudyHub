#include<bits/stdc++.h>
using namespace std;
bool primeCheck(int a){
    if(a<2)
    return false;
    if (a==2)
    return true;
    for(int i=2;i<a;i++){
        if(a%i==0)
        return false;
    }
}
int main(){
    int r,c;
    cin>>r;
    cin>>c;
    vector<vector<int>> smat;
    for(int i=0;i<r;i++){
        for(int j=0;j<c;j++){
            cin>>smat[i][j];
        }
    }
    vector<vector<int>> tmat;
    for(int i=0;i<r;i++){
        for(int j=0;j<c;j++){
            cin>>tmat[i][j];
        }
    }

   int count=0;
    for(int i=0;i<r;i++){
        for(int j=0;j<c;j++){
            if(tmat[i][j]==1)
            count++;

        }
    }
    if(!primeCheck(count))
  {
    cout<<"flip is -1"<<endl;
    return 0;
  }
    for(int i=0;i<r;i++){
        for(int j=0;j<c;j++){
            if(smat[i][j]!=tmat[i][j]){

            }
        }
    }
}